import {
  pgTable,
  uuid,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

// ---- Users / accounts -------------------------------------------------------
export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  username: text("username").notNull().unique(),
  email: text("email"),
  passwordHash: text("password_hash").notNull(),
  avatarSeed: text("avatar_seed").notNull().default("default"),
  xp: integer("xp").notNull().default(0),
  level: integer("level").notNull().default(1),
  manualRoleId: uuid("manual_role_id"),
  giftRoleId: uuid("gift_role_id"),
  status: text("status").notNull().default("active"), // active | blocked
  isAdmin: boolean("is_admin").notNull().default(false),
  isOwner: boolean("is_owner").notNull().default(false),
  testsCount: integer("tests_count").notNull().default(0),
  verifiedCount: integer("verified_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastActiveAt: timestamp("last_active_at").notNull().defaultNow(),
});

// ---- Sessions (httpOnly cookie auth for students + admins) ------------------
export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
});

// ---- Roles / ranks (configurable from admin) -------------------------------
export const roles = pgTable("roles", {
  id: uuid("id").primaryKey().defaultRandom(),
  key: text("key").notNull().unique(),
  name: text("name").notNull(),
  color: text("color").notNull().default("#cbd5e1"),
  glow: text("glow").notNull().default("#ffffff"),
  badge: text("badge").notNull().default("★"),
  levelRequirement: integer("level_requirement").notNull().default(1),
  xpRequirement: integer("xp_requirement").notNull().default(0),
  giftable: boolean("giftable").notNull().default(true),
  autoUnlock: boolean("auto_unlock").notNull().default(true),
  custom: boolean("custom").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
});

// ---- XP codes --------------------------------------------------------------
export const xpCodes = pgTable("xp_codes", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: text("code").notNull().unique(),
  xpReward: integer("xp_reward").notNull().default(0),
  unlimitedXp: boolean("unlimited_xp").notNull().default(false),
  active: boolean("active").notNull().default(true),
  maxUses: integer("max_uses"),
  currentUses: integer("current_uses").notNull().default(0),
  expiresAt: timestamp("expires_at"),
  onePerUser: boolean("one_per_user").notNull().default(true),
  createdById: uuid("created_by_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const xpCodeRedemptions = pgTable(
  "xp_code_redemptions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    codeId: uuid("code_id")
      .notNull()
      .references(() => xpCodes.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    uniq: uniqueIndex("redemptions_user_code_uniq").on(t.userId, t.codeId),
  })
);

// ---- Gifts (role gifting -> Gift Box) --------------------------------------
export const gifts = pgTable("gifts", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  type: text("type").notNull().default("role"),
  roleName: text("role_name").notNull(),
  roleColor: text("role_color").notNull().default("#ffffff"),
  roleBadge: text("role_badge").notNull().default("★"),
  roleId: uuid("role_id"),
  message: text("message"),
  claimed: boolean("claimed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---- Academic results ------------------------------------------------------
export const results = pgTable(
  "results",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    subject: text("subject"),
    testName: text("test_name"),
    chapter: text("chapter"),
    studentName: text("student_name"),
    marksObtained: integer("marks_obtained"),
    maxMarks: integer("max_marks"),
    percentage: integer("percentage"),
    confidence: integer("confidence"),
    status: text("status").notNull().default("pending"), // pending|verified|duplicate|rejected
    imageHash: text("image_hash"),
    perceptualHash: text("perceptual_hash"),
    imageDataUrl: text("image_data_url"),
    testDate: text("test_date"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    byUser: index("results_user_idx").on(t.userId),
    byHash: index("results_hash_idx").on(t.imageHash),
  })
);

// ---- Audit log -------------------------------------------------------------
export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  adminId: uuid("admin_id"),
  adminName: text("admin_name"),
  action: text("action").notNull(),
  details: text("details"),
  targetUserId: uuid("target_user_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const xpHistory = pgTable(
  "xp_history",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    amount: integer("amount").notNull(),
    reason: text("reason").notNull(),
    balanceAfter: integer("balance_after").notNull(),
    source: text("source").notNull().default("admin"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    byUser: index("xp_history_user_idx").on(t.userId),
  })
);

// ---- Configurable settings (key/value) -------------------------------------
export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});

// ---- Portfolio -------------------------------------------------------------
export const projects = pgTable("projects", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  features: text("features").array().notNull(),
  technologies: text("technologies").array().notNull(),
  category: text("category").notNull().default("Web"),
  imageUrl: text("image_url"),
  screenshots: jsonb("screenshots").notNull(),
  liveDemoUrl: text("live_demo_url"),
  sourceCodeUrl: text("source_code_url"),
  featured: boolean("featured").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
export type Role = typeof roles.$inferSelect;
export type XpCode = typeof xpCodes.$inferSelect;
export type Gift = typeof gifts.$inferSelect;
export type Result = typeof results.$inferSelect;
export type AuditLog = typeof auditLogs.$inferSelect;
export type XpHistory = typeof xpHistory.$inferSelect;
export type Project = typeof projects.$inferSelect;

export const DEFAULT_PROJECT_SCREENSHOTS = sql`'[]'::jsonb`;
