"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

type ToastKind = "ok" | "bad" | "gold" | "info" | "";
interface Toast {
  id: number;
  msg: string;
  kind: ToastKind;
}
interface LevelUpData {
  from: number;
  to: number;
}
interface RankData {
  name: string;
  color: string;
  glow: string;
  badge: string;
  description?: string;
}
interface GiftData {
  roleName: string;
  color: string;
  glow: string;
  badge: string;
}
interface Pop {
  id: number;
  amount: number;
  x: number;
  y: number;
}

interface FxCtx {
  toast: (msg: string, kind?: ToastKind) => void;
  popXp: (amount: number, x?: number, y?: number) => void;
  levelUp: (d: LevelUpData) => void;
  rankUnlock: (d: RankData) => void;
  giftOpen: (d: GiftData) => void;
  perf: boolean;
  setPerf: (v: boolean) => void;
  reduced: boolean;
  setReduced: (v: boolean) => void;
  sound: boolean;
  setSound: (v: boolean) => void;
}

const Ctx = createContext<FxCtx | null>(null);

export function useFx() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useFx must be used inside FxProvider");
  return c;
}

let actx: AudioContext | null = null;
function beep(freq: number, dur: number, type: OscillatorType = "sine", gain = 0.05) {
  try {
    const Ctor = window.AudioContext || (window as any).webkitAudioContext;
    actx = actx || new Ctor();
    const o = actx.createOscillator();
    const g = actx.createGain();
    o.type = type;
    o.frequency.value = freq;
    o.connect(g);
    g.connect(actx.destination);
    const t = actx.currentTime;
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.start(t);
    o.stop(t + dur);
  } catch {
    /* audio unavailable */
  }
}

function Bursts({
  count = 18,
  colors = ["#22d3ee", "#a855f7", "#ffd24a", "#2ee6a6"],
}: {
  count?: number;
  colors?: string[];
}) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        pointerEvents: "none",
        display: "grid",
        placeItems: "center",
      }}
    >
      {Array.from({ length: count }).map((_, i) => {
        const ang = (Math.PI * 2 * i) / count;
        const dist = 110 + Math.random() * 130;
        const x = Math.cos(ang) * dist;
        const y = Math.sin(ang) * dist;
        const c = colors[i % colors.length];
        return (
          <span
            key={i}
            className="burst"
            style={
              {
                "--bx": `${x}px`,
                "--by": `${y}px`,
                background: c,
                left: "50%",
                top: "50%",
                marginLeft: -4,
                marginTop: -4,
              } as React.CSSProperties
            }
          />
        );
      })}
    </div>
  );
}

function Overlay({
  onClose,
  children,
  wide,
}: {
  onClose: () => void;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="overlay" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        style={{ position: "relative", maxWidth: wide ? 640 : 420, width: "92vw" }}
      >
        {children}
      </div>
    </div>
  );
}

export function FxProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [lu, setLu] = useState<LevelUpData | null>(null);
  const [ru, setRu] = useState<RankData | null>(null);
  const [go, setGo] = useState<GiftData | null>(null);
  const [pops, setPops] = useState<Pop[]>([]);
  const [perf, setPerfS] = useState(false);
  const [reduced, setReducedS] = useState(false);
  const [sound, setSoundS] = useState(true);

  useEffect(() => {
    setPerfS(localStorage.getItem("aurora_perf") === "1");
    setReducedS(localStorage.getItem("aurora_motion") === "1");
    setSoundS(localStorage.getItem("aurora_sound") !== "0");
  }, []);
  useEffect(() => {
    document.body.classList.toggle("perf-mode", perf);
    localStorage.setItem("aurora_perf", perf ? "1" : "0");
  }, [perf]);
  useEffect(() => {
    document.body.classList.toggle("reduced-motion", reduced);
    localStorage.setItem("aurora_motion", reduced ? "1" : "0");
  }, [reduced]);
  useEffect(() => {
    localStorage.setItem("aurora_sound", sound ? "1" : "0");
  }, [sound]);

  const idRef = useRef(1);
  const toast = useCallback((msg: string, kind: ToastKind = "") => {
    const id = idRef.current++;
    setToasts((t) => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3400);
  }, []);
  const popXp = useCallback(
    (amount: number, x?: number, y?: number) => {
      const id = idRef.current++;
      const px = x ?? window.innerWidth / 2;
      const py = y ?? window.innerHeight / 2;
      setPops((p) => [...p, { id, amount, x: px, y: py }]);
      setTimeout(() => setPops((p) => p.filter((z) => z.id !== id)), 1400);
      beep(880, 0.12, "triangle", 0.05);
    },
    []
  );
  const fanfare = useCallback(() => {
    [523, 659, 784, 1046].forEach((f, i) =>
      setTimeout(() => beep(f, 0.2, "triangle", 0.06), i * 120)
    );
  }, []);
  const levelUp = useCallback(
    (d: LevelUpData) => {
      setLu(d);
      if (sound) fanfare();
    },
    [sound, fanfare]
  );
  const rankUnlock = useCallback(
    (d: RankData) => {
      setRu(d);
      if (sound) fanfare();
    },
    [sound, fanfare]
  );
  const giftOpen = useCallback(
    (d: GiftData) => {
      setGo(d);
      if (sound) fanfare();
    },
    [sound, fanfare]
  );

  const value = useMemo(
    () => ({
      toast,
      popXp,
      levelUp,
      rankUnlock,
      giftOpen,
      perf,
      setPerf: setPerfS,
      reduced,
      setReduced: setReducedS,
      sound,
      setSound: setSoundS,
    }),
    [toast, popXp, levelUp, rankUnlock, giftOpen, perf, reduced, sound]
  );

  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="toast-wrap">
        {toasts.map((t) => (
          <div key={t.id} className={`toast ${t.kind}`}>
            {t.msg}
          </div>
        ))}
      </div>
      {pops.map((p) => (
        <div
          key={p.id}
          className="xp-pop"
          style={{ left: p.x, top: p.y, fontSize: "1.5rem" }}
        >
          +{p.amount} XP
        </div>
      ))}

      {lu && (
        <Overlay onClose={() => setLu(null)}>
          <div
            className="glass-solid hud neon-edge"
            style={{ padding: "2.2rem 1.6rem", textAlign: "center", position: "relative" }}
          >
            <Bursts count={22} />
            <div
              style={{
                fontFamily: "Orbitron",
                letterSpacing: "0.2em",
                color: "var(--neon-2)",
                fontSize: "0.8rem",
              }}
            >
              LEVEL UP
            </div>
            <div
              style={{
                fontFamily: "Orbitron",
                fontSize: "3rem",
                fontWeight: 800,
                margin: "0.6rem 0",
                background: "linear-gradient(90deg,#22d3ee,#a855f7,#ffd24a)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              {lu.from} → {lu.to}
            </div>
            <button className="btn btn-primary" onClick={() => setLu(null)}>
              Continue
            </button>
          </div>
        </Overlay>
      )}

      {ru && (
        <Overlay onClose={() => setRu(null)} wide>
          <div
            className="glass-solid hud neon-edge"
            style={{ padding: "2rem", textAlign: "center", position: "relative" }}
          >
            <Bursts count={26} colors={[ru.color, ru.glow, "#ffffff"]} />
            <div
              style={{
                fontFamily: "Orbitron",
                letterSpacing: "0.22em",
                color: "var(--muted)",
                fontSize: "0.78rem",
              }}
            >
              NEW RANK UNLOCKED
            </div>
            <div style={{ margin: "1rem auto" }}>
              <div
                className="rank-orb fx-aura fx-glow"
                style={
                  {
                    margin: "0 auto",
                    width: 124,
                    height: 124,
                    fontSize: "2.6rem",
                    "--rk-color": ru.color,
                    "--rk-glow": ru.glow,
                  } as React.CSSProperties
                }
              >
                {ru.badge}
              </div>
            </div>
            <div
              style={{
                fontFamily: "Orbitron",
                fontSize: "2rem",
                fontWeight: 800,
                color: ru.color,
                textShadow: `0 0 24px ${ru.glow}`,
              }}
            >
              {ru.name}
            </div>
            {ru.description && (
              <p style={{ color: "var(--muted)", marginTop: 8 }}>{ru.description}</p>
            )}
            <button
              className="btn btn-primary"
              style={{ marginTop: 16 }}
              onClick={() => setRu(null)}
            >
              Awesome
            </button>
          </div>
        </Overlay>
      )}

      {go && (
        <Overlay onClose={() => setGo(null)} wide>
          <div
            className="glass-solid hud neon-edge"
            style={{ padding: "2rem", textAlign: "center", position: "relative" }}
          >
            <Bursts count={30} colors={[go.color, go.glow, "#ffffff", "#ffd24a"]} />
            <div
              style={{
                fontFamily: "Orbitron",
                letterSpacing: "0.2em",
                color: "var(--gold)",
                fontSize: "0.78rem",
              }}
            >
              ROLE RECEIVED!
            </div>
            <div style={{ margin: "1rem auto" }}>
              <div
                className="rank-orb fx-aura fx-glow"
                style={
                  {
                    margin: "0 auto",
                    width: 120,
                    height: 120,
                    "--rk-color": go.color,
                    "--rk-glow": go.glow,
                  } as React.CSSProperties
                }
              >
                {go.badge}
              </div>
            </div>
            <div
              style={{
                fontFamily: "Orbitron",
                fontSize: "1.8rem",
                fontWeight: 800,
                color: go.color,
              }}
            >
              {go.roleName}
            </div>
            <button
              className="btn btn-primary"
              style={{ marginTop: 16 }}
              onClick={() => setGo(null)}
            >
              Equip
            </button>
          </div>
        </Overlay>
      )}
    </Ctx.Provider>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <>
      <div className="app-bg" aria-hidden />
      <FxProvider>{children}</FxProvider>
    </>
  );
}
