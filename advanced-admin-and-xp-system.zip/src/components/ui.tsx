"use client";

import React, { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/client";

export function Avatar({ seed, size = 44 }: { seed: string; size?: number }) {
  let h = 0;
  for (const c of seed) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  const hue = h % 360;
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: 12,
        background: `linear-gradient(135deg,hsl(${hue} 85% 58%),hsl(${(hue + 60) % 360} 85% 44%))`,
        display: "grid",
        placeItems: "center",
        fontFamily: "Orbitron",
        fontWeight: 700,
        color: "#05060f",
        border: "1px solid rgba(255,255,255,.28)",
        boxShadow: `0 0 14px hsla(${hue},85%,60%,.5)`,
        fontSize: size * 0.42,
        flexShrink: 0,
      }}
    >
      {(seed[0] || "?").toUpperCase()}
    </div>
  );
}

export function RankBadge({ role, className = "" }: { role: any; className?: string }) {
  if (!role) return null;
  return (
    <span
      className={`rank-badge ${role.effect || ""} ${className}`}
      style={
        { "--rk-color": role.color, "--rk-glow": role.glow } as React.CSSProperties
      }
    >
      <span>{role.badge}</span>
      {role.name}
    </span>
  );
}

export function RankOrb({
  role,
  size = 96,
  label,
}: {
  role: any;
  size?: number;
  label?: boolean;
}) {
  if (!role) return null;
  return (
    <div style={{ textAlign: "center" }}>
      <div
        className={`rank-orb ${role.effect || ""}`}
        style={
          {
            width: size,
            height: size,
            fontSize: size * 0.34,
            "--rk-color": role.color,
            "--rk-glow": role.glow,
          } as React.CSSProperties
        }
      >
        {role.badge}
      </div>
      {label && (
        <div
          style={{
            marginTop: 8,
            fontFamily: "Orbitron",
            letterSpacing: ".12em",
            color: role.color,
            fontSize: ".8rem",
          }}
        >
          {role.name}
        </div>
      )}
    </div>
  );
}

export function XpBar({
  progress,
  showLabel = true,
}: {
  progress: { level: number; current: number; needed: number; pct: number };
  showLabel?: boolean;
}) {
  return (
    <div>
      {showLabel && (
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            fontSize: ".74rem",
            color: "var(--muted)",
            marginBottom: 6,
            fontFamily: "Orbitron",
          }}
        >
          <span>LEVEL {progress.level}</span>
          <span>
            {progress.current.toLocaleString()} / {progress.needed.toLocaleString()} XP
          </span>
        </div>
      )}
      <div className="xp-track">
        <div className="xp-fill" style={{ width: `${progress.pct}%` }} />
      </div>
    </div>
  );
}

export function Modal({
  title,
  onClose,
  children,
  width = 580,
}: {
  title: React.ReactNode;
  onClose: () => void;
  children: React.ReactNode;
  width?: number;
}) {
  return (
    <div className="overlay" onClick={onClose}>
      <div
        className="glass-solid hud neon-edge"
        style={{
          width,
          maxWidth: "94vw",
          maxHeight: "90vh",
          overflow: "auto",
          padding: "1.4rem",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 14,
            gap: 12,
          }}
        >
          <h3 style={{ margin: 0, fontSize: "1rem", letterSpacing: ".08em" }}>{title}</h3>
          <button className="btn btn-ghost" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Spinner() {
  return (
    <div
      className="spin"
      style={{
        width: 22,
        height: 22,
        border: "3px solid rgba(255,255,255,.18)",
        borderTopColor: "var(--neon-2)",
        borderRadius: "50%",
      }}
    />
  );
}

export function Stat({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="glass hud" style={{ padding: "1rem 1.1rem" }}>
      <div
        style={{
          fontSize: ".64rem",
          letterSpacing: ".12em",
          color: "var(--muted)",
          textTransform: "uppercase",
          fontFamily: "Orbitron",
        }}
      >
        {label}
      </div>
      <div style={{ fontSize: "1.5rem", fontWeight: 700, fontFamily: "Orbitron", marginTop: 4 }}>
        {value}
      </div>
    </div>
  );
}

export function Toggle({
  on,
  onChange,
  label,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      onClick={() => onChange(!on)}
      className="btn btn-ghost"
      style={{
        borderColor: on ? "var(--ok)" : "var(--border)",
        color: on ? "var(--ok)" : undefined,
        fontSize: ".68rem",
      }}
    >
      {label}: {on ? "ON" : "OFF"}
    </button>
  );
}

export function useSession() {
  const [state, setState] = useState<{ user: any | null; loading: boolean }>({
    user: null,
    loading: true,
  });
  const reload = useCallback(async () => {
    setState((s) => ({ ...s, loading: true }));
    try {
      const r = await api<{ user: any }>("/api/session");
      setState({ user: r.user, loading: false });
    } catch {
      setState({ user: null, loading: false });
    }
  }, []);
  useEffect(() => {
    reload();
  }, [reload]);
  return { ...state, reload };
}
