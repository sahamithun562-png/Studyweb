import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";
import { cookies } from "next/headers";
import { eq, and, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users, auditLogs } from "@/db/schema";

export const SESSION_COOKIE = "aurora_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days

export async function hashPassword(p: string) {
  return bcrypt.hash(p, 10);
}
export async function verifyPassword(p: string, hash: string) {
  return bcrypt.compare(p, hash);
}

export async function createSession(userId: string): Promise<string> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  await db.insert(sessions).values({ token, userId, expiresAt });
  return token;
}

export async function setSessionCookie(token: string) {
  const c = await cookies();
  c.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: Math.floor(SESSION_TTL_MS / 1000),
    secure: process.env.NODE_ENV === "production",
  });
}

export async function clearSessionCookie() {
  const c = await cookies();
  c.delete(SESSION_COOKIE);
}

export type SessionUser = typeof users.$inferSelect;

export async function getCurrentUser(): Promise<SessionUser | null> {
  try {
    const c = await cookies();
    const token = c.get(SESSION_COOKIE)?.value;
    if (!token) return null;
    const rows = await db
      .select({ user: users })
      .from(sessions)
      .innerJoin(users, eq(users.id, sessions.userId))
      .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
      .limit(1);
    if (!rows.length) return null;
    const user = rows[0].user;
    if (user.status === "blocked") return null;
    // throttle last-active writes
    const age = Date.now() - user.lastActiveAt.getTime();
    if (age > 60_000) {
      await db
        .update(users)
        .set({ lastActiveAt: new Date() })
        .where(eq(users.id, user.id));
    }
    return user;
  } catch {
    return null;
  }
}

export async function requireUser(): Promise<SessionUser | null> {
  const u = await getCurrentUser();
  return u && u.status === "active" ? u : null;
}

export async function requireAdminUser(): Promise<SessionUser | null> {
  const u = await getCurrentUser();
  if (!u || !u.isAdmin || u.status !== "active") return null;
  return u;
}

export async function destroySession() {
  try {
    const c = await cookies();
    const token = c.get(SESSION_COOKIE)?.value;
    if (token) {
      await db.delete(sessions).where(eq(sessions.token, token));
    }
    await clearSessionCookie();
  } catch {
    /* noop */
  }
}

export async function writeAudit(
  admin: SessionUser,
  action: string,
  details: string,
  targetUserId?: string
) {
  try {
    await db.insert(auditLogs).values({
      adminId: admin.id,
      adminName: admin.username,
      action,
      details,
      targetUserId: targetUserId ?? null,
    });
  } catch {
    /* noop */
  }
}

/* ---- In-memory failed-login protection ---- */
type Attempt = { count: number; until: number };
const attempts = new Map<string, Attempt>();
const MAX_ATTEMPTS = 5;
const LOCK_MS = 60_000;

export function checkRateLimit(key: string): { ok: boolean; retryAfter: number } {
  const a = attempts.get(key);
  const now = Date.now();
  if (a && a.until > now) {
    return { ok: false, retryAfter: Math.ceil((a.until - now) / 1000) };
  }
  return { ok: true, retryAfter: 0 };
}

export function recordFailedLogin(key: string) {
  const now = Date.now();
  const a = attempts.get(key) ?? { count: 0, until: 0 };
  a.count += 1;
  if (a.count >= MAX_ATTEMPTS) {
    a.until = now + LOCK_MS;
    a.count = 0;
  }
  attempts.set(key, a);
}

export function clearFailedLogin(key: string) {
  attempts.delete(key);
}
