export async function api<T = any>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    ...init,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...(init?.headers || {}) },
  });
  let data: any = null;
  try {
    data = await res.json();
  } catch {
    /* not json */
  }
  if (!res.ok)
    throw new Error((data && data.error) || `Request failed (${res.status})`);
  return data as T;
}

export async function apiForm<T = any>(path: string, fd: FormData): Promise<T> {
  const res = await fetch(path, { method: "POST", body: fd, credentials: "include" });
  let data: any = null;
  try {
    data = await res.json();
  } catch {
    /* not json */
  }
  if (!res.ok)
    throw new Error((data && data.error) || `Upload failed (${res.status})`);
  return data as T;
}
