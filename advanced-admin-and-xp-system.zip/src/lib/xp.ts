// Pure XP <-> level math. Level is always derived from total XP so the
// "+3 XP" image bonus can NEVER silently become "+3 levels".

export function levelUpCost(level: number, base: number) {
  return Math.max(1, base) * Math.max(1, level);
}

/** Cumulative XP required to have reached `level` (level 1 => 0). */
export function xpAtLevel(level: number, base: number) {
  if (level <= 1) return 0;
  const n = level - 1;
  return Math.floor((Math.max(1, base) * n * (n + 1)) / 2);
}

export function levelFromXp(xp: number, base: number) {
  let level = 1;
  const b = Math.max(1, base);
  // guard against runaway loops for absurd xp
  let guard = 0;
  while (xpAtLevel(level + 1, b) <= xp && guard < 100000) {
    level++;
    guard++;
  }
  return level;
}

export interface LevelProgress {
  level: number;
  current: number;
  needed: number;
  pct: number;
}

export function levelProgress(xp: number, base: number): LevelProgress {
  const level = levelFromXp(xp, base);
  const floor = xpAtLevel(level, base);
  const ceil = xpAtLevel(level + 1, base);
  const current = xp - floor;
  const needed = ceil - floor;
  return {
    level,
    current,
    needed,
    pct: needed > 0 ? Math.min(100, (current / needed) * 100) : 100,
  };
}
