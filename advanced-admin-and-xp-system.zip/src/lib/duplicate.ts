import { eq } from "drizzle-orm";
import { db } from "@/db";
import { results } from "@/db/schema";
import { hamming } from "./image-hash";

export type DupKind = "none" | "exact" | "duplicate" | "possible";

export interface DupExisting {
  id: string;
  userId: string | null;
  subject: string | null;
}

export interface DupResult {
  kind: DupKind;
  distance?: number;
  existing?: DupExisting;
}

/**
 * Detect exact (content-hash) and perceptual (dHash) duplicates across the
 * whole result set. Detects renames, resizes, recompression, screenshots and
 * minor edits because dHash is robust to those transformations.
 */
export async function detectDuplicate(
  content: string,
  phash: string | null,
  threshold: number,
  possibleThreshold: number
): Promise<DupResult> {
  const exact = await db
    .select({
      id: results.id,
      userId: results.userId,
      subject: results.subject,
    })
    .from(results)
    .where(eq(results.imageHash, content))
    .limit(1);
  if (exact.length) return { kind: "exact", existing: exact[0] };

  if (phash) {
    const all = await db
      .select({
        id: results.id,
        userId: results.userId,
        subject: results.subject,
        ph: results.perceptualHash,
      })
      .from(results);
    let best = { d: 999, row: null as DupExisting | null };
    for (const r of all) {
      if (!r.ph) continue;
      const d = hamming(phash, r.ph);
      if (d < best.d) {
        best = {
          d,
          row: { id: r.id, userId: r.userId, subject: r.subject },
        };
      }
    }
    if (best.row && best.d <= threshold) {
      return { kind: "duplicate", distance: best.d, existing: best.row };
    }
    if (best.row && best.d <= possibleThreshold) {
      return { kind: "possible", distance: best.d, existing: best.row };
    }
  }
  return { kind: "none" };
}
