import { db } from "@/db";
import { roles, results } from "@/db/schema";
import { resolveRank, effectForRole } from "./ranks";
import { getProgressFor } from "./progress";
import { count, sql, eq } from "drizzle-orm";
import type { User, Role } from "@/db/schema";

let rolesCache: { at: number; data: Role[] } | null = null;

export async function getRoles(): Promise<Role[]> {
  const now = Date.now();
  if (rolesCache && now - rolesCache.at < 3000) return rolesCache.data;
  const data = await db.select().from(roles);
  rolesCache = { at: now, data };
  return data;
}

export function invalidateRolesCache() {
  rolesCache = null;
}

export async function getCounts(userId: string) {
  const rows = await db
    .select({
      tests: count(),
      verified: sql<number>`count(*) filter (where ${results.status} = 'verified')`,
      avgPct: sql<number>`coalesce(avg(${results.percentage}) filter (where ${results.status} = 'verified'), 0)`,
    })
    .from(results)
    .where(eq(results.userId, userId));
  const r = rows[0] ?? { tests: 0, verified: 0, avgPct: 0 };
  return {
    tests: Number(r.tests) || 0,
    verified: Number(r.verified) || 0,
    avgPct: Math.round(Number(r.avgPct) || 0),
  };
}

export async function profileOf(u: User) {
  const roleList = await getRoles();
  const role = resolveRank(u.level, u.manualRoleId, u.giftRoleId, roleList);
  const progress = await getProgressFor(u.xp);
  const counts = await getCounts(u.id);
  return {
    id: u.id,
    username: u.username,
    avatarSeed: u.avatarSeed,
    email: u.email,
    xp: u.xp,
    level: u.level,
    status: u.status,
    isAdmin: u.isAdmin,
    isOwner: u.isOwner,
    testsCount: counts.tests,
    verifiedCount: counts.verified,
    avgPct: counts.avgPct,
    createdAt: u.createdAt,
    lastActiveAt: u.lastActiveAt,
    role: { ...role, effect: effectForRole(role) },
    progress,
  };
}

export type Profile = Awaited<ReturnType<typeof profileOf>>;
