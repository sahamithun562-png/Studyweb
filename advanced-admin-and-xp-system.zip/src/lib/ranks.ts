import type { Role } from "@/db/schema";

export interface DefaultRoleSeed {
  key: string;
  name: string;
  color: string;
  glow: string;
  badge: string;
  levelRequirement: number;
  sortOrder: number;
  effect: string; // css effect class hint for the tier
}

export const DEFAULT_ROLES: DefaultRoleSeed[] = [
  { key: "classic", name: "CLASSIC", color: "#cbd5e1", glow: "#e2e8f0", badge: "◇", levelRequirement: 1, sortOrder: 1, effect: "fx-glow" },
  { key: "legendary", name: "LEGENDARY", color: "#ffd24a", glow: "#ffae00", badge: "★", levelRequirement: 10, sortOrder: 2, effect: "fx-border-flow" },
  { key: "mythical", name: "MYTHICAL", color: "#b06bff", glow: "#d8b4fe", badge: "✦", levelRequirement: 25, sortOrder: 3, effect: "fx-aura" },
  { key: "god", name: "GOD", color: "#fff3c4", glow: "#ffd24a", badge: "✸", levelRequirement: 50, sortOrder: 4, effect: "fx-aura fx-glow" },
  { key: "galaxy", name: "GALAXY", color: "#6d8bff", glow: "#b06bff", badge: "✺", levelRequirement: 100, sortOrder: 5, effect: "fx-stars fx-aura" },
  { key: "inf", name: "INF", color: "#22d3ee", glow: "#ff4df0", badge: "∞", levelRequirement: 200, sortOrder: 6, effect: "fx-border-flow fx-aura fx-multicolor" },
];

export const EFFECT_OPTIONS = [
  { key: "fx-glow", label: "Simple glow" },
  { key: "fx-border-flow", label: "Animated border" },
  { key: "fx-aura", label: "Energy aura" },
  { key: "fx-stars", label: "Moving stars" },
  { key: "fx-multicolor", label: "Multicolor shift" },
];

export function resolveRank(
  level: number,
  manualRoleId: string | null,
  giftRoleId: string | null,
  roles: Role[]
): Role {
  const byId = (id: string | null) => roles.find((r) => r.id === id);
  if (giftRoleId) {
    const g = byId(giftRoleId);
    if (g) return g;
  }
  if (manualRoleId) {
    const m = byId(manualRoleId);
    if (m) return m;
  }
  const auto = roles
    .filter((r) => r.autoUnlock)
    .sort((a, b) => a.levelRequirement - b.levelRequirement);
  let chosen = auto[0];
  for (const r of auto) {
    if (level >= r.levelRequirement) chosen = r;
  }
  if (chosen) return chosen;
  return roles.sort((a, b) => a.sortOrder - b.sortOrder)[0];
}

export function effectForRole(role: Role | undefined): string {
  if (!role) return "fx-glow";
  const seed = DEFAULT_ROLES.find((r) => r.key === role.key);
  return seed?.effect ?? "fx-glow";
}
