import sharp from "sharp";
import { createHash } from "crypto";

export function contentHash(buf: Buffer): string {
  return createHash("sha256").update(buf).digest("hex");
}

export interface ImageSignature {
  content: string;
  phash: string | null;
  display: string | null;
  width: number;
  height: number;
}

/**
 * Compute a content hash (exact match) + perceptual dHash (similarity).
 * dHash is resilient to rename / resize / compress / minor edits.
 */
export async function computeImageSignature(buf: Buffer): Promise<ImageSignature> {
  const content = contentHash(buf);
  let phash: string | null = null;
  let display: string | null = null;
  let width = 0;
  let height = 0;
  try {
    const meta = await sharp(buf).metadata();
    width = meta.width ?? 0;
    height = meta.height ?? 0;
  } catch {
    /* ignore */
  }
  try {
    const raw = await sharp(buf)
      .grayscale()
      .resize(9, 8, { fit: "fill" })
      .raw()
      .toBuffer();
    const vals = Array.from(raw);
    let bits = "";
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 9; c++) {
        const left = vals[r * 9 + c];
        const right = vals[r * 9 + c + 1];
        bits += left > right ? "1" : "0";
      }
    }
    phash = bits;
  } catch {
    phash = null;
  }
  try {
    const disp = await sharp(buf)
      .resize(900, 900, { fit: "inside", withoutEnlargement: true })
      .jpeg({ quality: 78 })
      .toBuffer();
    display = `data:image/jpeg;base64,${disp.toString("base64")}`;
  } catch {
    display = null;
  }
  return { content, phash, display, width, height };
}

export function hamming(a?: string | null, b?: string | null): number {
  if (!a || !b || a.length !== b.length) return 999;
  let d = 0;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) d++;
  return d;
}
