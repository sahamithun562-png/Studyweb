import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, xpHistory } from "@/db/schema";
import { getAllSettings, num } from "./settings";
import { levelFromXp, levelProgress, xpAtLevel, type LevelProgress } from "./xp";

export interface XpResult {
  oldXp: number;
  newXp: number;
  oldLevel: number;
  newLevel: number;
  leveledUp: boolean;
}

async function baseLevelXp(): Promise<number> {
  const s = await getAllSettings();
  return num(s.xp_per_level_base, 100);
}

export async function applyXp(
  userId: string,
  delta: number,
  reason: string,
  source: string
): Promise<XpResult | null> {
  const b = await baseLevelXp();
  const rows = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!rows.length) return null;
  const u = rows[0];
  const newXp = Math.max(0, u.xp + delta);
  const newLevel = levelFromXp(newXp, b);
  await db.update(users).set({ xp: newXp, level: newLevel }).where(eq(users.id, userId));
  await db.insert(xpHistory).values({
    userId,
    amount: delta,
    reason,
    balanceAfter: newXp,
    source,
  });
  return { oldXp: u.xp, newXp, oldLevel: u.level, newLevel, leveledUp: newLevel > u.level };
}

export async function setExactXp(
  userId: string,
  xp: number,
  reason: string
): Promise<XpResult | null> {
  const b = await baseLevelXp();
  const rows = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!rows.length) return null;
  const u = rows[0];
  const safe = Math.max(0, Math.floor(xp));
  const newLevel = levelFromXp(safe, b);
  await db.update(users).set({ xp: safe, level: newLevel }).where(eq(users.id, userId));
  await db.insert(xpHistory).values({
    userId,
    amount: safe - u.xp,
    reason,
    balanceAfter: safe,
    source: "admin",
  });
  return { oldXp: u.xp, newXp: safe, oldLevel: u.level, newLevel, leveledUp: newLevel > u.level };
}

export async function setExactLevel(
  userId: string,
  level: number,
  reason: string
): Promise<XpResult | null> {
  const b = await baseLevelXp();
  const rows = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!rows.length) return null;
  const u = rows[0];
  const L = Math.max(1, Math.floor(level));
  const xp = xpAtLevel(L, b);
  const newLevel = levelFromXp(xp, b);
  await db.update(users).set({ xp, level: newLevel }).where(eq(users.id, userId));
  await db.insert(xpHistory).values({
    userId,
    amount: xp - u.xp,
    reason,
    balanceAfter: xp,
    source: "admin",
  });
  return { oldXp: u.xp, newXp: xp, oldLevel: u.level, newLevel, leveledUp: newLevel > u.level };
}

export async function resetXp(userId: string) {
  return setExactXp(userId, 0, "XP reset by admin");
}
export async function resetLevel(userId: string) {
  return setExactLevel(userId, 1, "Level reset by admin");
}

export async function getProgressFor(xp: number): Promise<LevelProgress> {
  const b = await baseLevelXp();
  return levelProgress(xp, b);
}
