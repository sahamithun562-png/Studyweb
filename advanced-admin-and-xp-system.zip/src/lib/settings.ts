import { eq } from "drizzle-orm";
import { db } from "@/db";
import { settings } from "@/db/schema";

export const DEFAULT_SETTINGS: Record<string, string> = {
  xp_per_verified_result: "50",
  xp_per_image_verified: "3",
  xp_per_level_base: "100",
  duplicate_threshold: "5", // hamming distance <= -> duplicate
  possible_duplicate_threshold: "10", // <= -> possible (manual review)
  analyzer_confidence_min: "70", // below this -> manual review
};

let cache: { at: number; data: Record<string, string> } | null = null;
const TTL = 4000;

export async function getAllSettings(): Promise<Record<string, string>> {
  const now = Date.now();
  if (cache && now - cache.at < TTL) return cache.data;
  const rows = await db.select().from(settings);
  const data = {
    ...DEFAULT_SETTINGS,
    ...Object.fromEntries(rows.map((r) => [r.key, r.value])),
  };
  cache = { at: now, data };
  return data;
}

export function num(v: string | undefined, fallback: number): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function invalidateSettingsCache() {
  cache = null;
}

export async function upsertSetting(key: string, value: string) {
  await db
    .insert(settings)
    .values({ key, value })
    .onConflictDoUpdate({ target: settings.key, set: { value } });
  invalidateSettingsCache();
}
