import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  users,
  roles,
  settings as settingsTable,
  xpCodes,
  projects,
} from "@/db/schema";
import { hashPassword } from "./auth";
import { DEFAULT_ROLES } from "./ranks";
import { DEFAULT_SETTINGS } from "./settings";
import { levelFromXp } from "./xp";

let seeded = false;

const SAMPLE_STUDENTS = [
  { username: "student1", xp: 132600, tests: 24, verified: 21, avatar: "nebula" },
  { username: "student2", xp: 66600, tests: 18, verified: 16, avatar: "comet" },
  { username: "student3", xp: 23100, tests: 12, verified: 11, avatar: "orbit" },
  { username: "student4", xp: 4500, tests: 7, verified: 6, avatar: "pulse" },
  { username: "student5", xp: 1200, tests: 3, verified: 2, avatar: "spark" },
  { username: "student6", xp: 300, tests: 1, verified: 1, avatar: "ember" },
];

/**
 * Idempotent bootstrap. Runs on health-checks / first requests so a freshly
 * initialised database is always ready. Safe to call repeatedly.
 */
export async function ensureSeed() {
  if (seeded) return;
  const owners = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.isOwner, true))
    .limit(1);
  if (owners.length) {
    seeded = true;
    return;
  }

  for (const r of DEFAULT_ROLES) {
    await db
      .insert(roles)
      .values({
        key: r.key,
        name: r.name,
        color: r.color,
        glow: r.glow,
        badge: r.badge,
        levelRequirement: r.levelRequirement,
        xpRequirement: 0,
        giftable: r.key !== "classic",
        autoUnlock: true,
        custom: false,
        sortOrder: r.sortOrder,
      })
      .onConflictDoNothing();
  }

  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) {
    await db
      .insert(settingsTable)
      .values({ key: k, value: v })
      .onConflictDoNothing();
  }

  const ownerPw = process.env.ADMIN_PASSWORD ?? "mrinxtappu";
  const ownerUser = process.env.OWNER_USERNAME ?? "owner";
  const hash = await hashPassword(ownerPw);
  const [owner] = await db
    .insert(users)
    .values({
      username: ownerUser,
      passwordHash: hash,
      isAdmin: true,
      isOwner: true,
      xp: 250000,
      level: 200,
      avatarSeed: "owner",
      email: "owner@aurora.local",
    })
    .returning();

  const demoPw = process.env.DEMO_STUDENT_PASSWORD ?? "student123";
  const demoHash = await hashPassword(demoPw);
  for (const s of SAMPLE_STUDENTS) {
    const lvl = levelFromXp(s.xp, 100);
    await db
      .insert(users)
      .values({
        username: s.username,
        passwordHash: demoHash,
        xp: s.xp,
        level: lvl,
        testsCount: s.tests,
        verifiedCount: s.verified,
        avatarSeed: s.avatar,
      })
      .onConflictDoNothing();
  }

  await db
    .insert(xpCodes)
    .values([
      {
        code: "WELCOME500",
        xpReward: 500,
        maxUses: 100,
        active: true,
        onePerUser: true,
        createdById: owner.id,
      },
      {
        code: "STUDY100",
        xpReward: 100,
        maxUses: 1000,
        active: true,
        onePerUser: true,
        createdById: owner.id,
      },
      {
        code: "tappuxdmrin",
        xpReward: 0,
        unlimitedXp: true,
        active: true,
        onePerUser: true,
        createdById: owner.id,
      },
    ])
    .onConflictDoNothing();

  await db
    .insert(projects)
    .values([
      {
        name: "Neural Trade Engine",
        description:
          "An AI-powered market analysis engine that forecasts asset trends using transformer models trained on multi-year live data streams.",
        features: [
          "Real-time transformer inference",
          "Strategy backtesting suite",
          "Automated risk scoring",
          "Live WebSocket dashboards",
        ],
        technologies: ["Python", "PyTorch", "FastAPI", "React", "PostgreSQL"],
        category: "AI / Data",
        imageUrl: "https://picsum.photos/seed/neural/900/560",
        screenshots: [
          "https://picsum.photos/seed/neural1/900/560",
          "https://picsum.photos/seed/neural2/900/560",
          "https://picsum.photos/seed/neural3/900/560",
        ],
        liveDemoUrl: "#",
        sourceCodeUrl: "#",
        featured: true,
        sortOrder: 1,
      },
      {
        name: "Aurora UI Kit",
        description:
          "A futuristic component library with glassmorphism, neon borders and HUD widgets built for high-performance dashboards.",
        features: ["60+ animated components", "Dark-first theming", "Tree-shakeable", "Zero-runtime CSS"],
        technologies: ["TypeScript", "React", "Tailwind", "Vite"],
        category: "Web",
        imageUrl: "https://picsum.photos/seed/auroraui/900/560",
        screenshots: [
          "https://picsum.photos/seed/auroraui1/900/560",
          "https://picsum.photos/seed/auroraui2/900/560",
        ],
        liveDemoUrl: "#",
        sourceCodeUrl: "#",
        featured: true,
        sortOrder: 2,
      },
      {
        name: "Orbit Messenger",
        description:
          "End-to-end encrypted cross-platform chat app with realtime presence, voice rooms and a slick mobile UI.",
        features: ["E2E encryption", "Voice rooms", "Offline sync", "Push notifications"],
        technologies: ["React Native", "Node.js", "WebRTC", "Redis"],
        category: "Mobile App",
        imageUrl: "https://picsum.photos/seed/orbit/900/560",
        screenshots: [
          "https://picsum.photos/seed/orbit1/900/560",
          "https://picsum.photos/seed/orbit2/900/560",
          "https://picsum.photos/seed/orbit3/900/560",
        ],
        liveDemoUrl: "#",
        sourceCodeUrl: "#",
        featured: false,
        sortOrder: 3,
      },
      {
        name: "Pulse Fitness AI",
        description:
          "A computer-vision workout coach that tracks reps and form in real time from a single phone camera.",
        features: ["Pose estimation", "Rep counting", "Form feedback", "Progress analytics"],
        technologies: ["Python", "MediaPipe", "TensorFlow", "Flutter"],
        category: "AI / Data",
        imageUrl: "https://picsum.photos/seed/pulse/900/560",
        screenshots: [
          "https://picsum.photos/seed/pulse1/900/560",
          "https://picsum.photos/seed/pulse2/900/560",
        ],
        liveDemoUrl: "#",
        sourceCodeUrl: "#",
        featured: false,
        sortOrder: 4,
      },
    ])
    .onConflictDoNothing();

  seeded = true;
}
