"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api, apiForm } from "@/lib/client";
import { useFx } from "@/components/fx";
import {
  useSession,
  Avatar,
  RankBadge,
  RankOrb,
  XpBar,
  Stat,
  Modal,
  Spinner,
  Toggle,
} from "@/components/ui";

export default function Dashboard() {
  const { user, loading, reload } = useSession();
  const router = useRouter();
  const fx = useFx();
  const prev = useRef<{ level: number; rank?: string } | null>(null);

  const [gifts, setGifts] = useState<any[]>([]);
  const [unread, setUnread] = useState(0);
  const [giftModal, setGiftModal] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [analysis, setAnalysis] = useState<any | null>(null);
  const [results, setResults] = useState<any[]>([]);
  const [code, setCode] = useState("");

  const loadGifts = useCallback(async () => {
    try {
      const r = await api<{ gifts: any[]; unread: number }>("/api/gifts");
      setGifts(r.gifts);
      setUnread(r.unread);
    } catch {
      /* noop */
    }
  }, []);

  const loadResults = useCallback(async () => {
    try {
      const r = await api<{ results: any[] }>("/api/results");
      setResults(r.results);
    } catch {
      /* noop */
    }
  }, []);

  useEffect(() => {
    loadGifts();
    loadResults();
  }, [loadGifts, loadResults]);

  useEffect(() => {
    if (!loading && !user) router.replace("/auth");
  }, [loading, user, router]);

  useEffect(() => {
    if (!user) return;
    const cur = { level: user.level, rank: user.role?.key };
    if (prev.current) {
      if (cur.level > prev.current.level) fx.levelUp({ from: prev.current.level, to: cur.level });
      if (cur.rank && prev.current.rank && cur.rank !== prev.current.rank) {
        const r = user.role;
        fx.rankUnlock({
          name: r.name,
          color: r.color,
          glow: r.glow,
          badge: r.badge,
          description: "A new rank has been unlocked.",
        });
      }
    }
    prev.current = cur;
  }, [user, fx]);

  async function logout() {
    try {
      await api("/api/auth", { method: "POST", body: JSON.stringify({ action: "logout" }) });
    } catch {
      /* noop */
    }
    router.push("/");
  }

  async function onUpload(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    setUploading(true);
    try {
      const r = await apiForm<any>("/api/results", fd);
      form.reset();
      if (r.status === "duplicate") {
        fx.toast(r.message, "bad");
        loadResults();
      } else {
        setAnalysis(r);
      }
    } catch (err: any) {
      fx.toast(err.message, "bad");
    } finally {
      setUploading(false);
    }
  }

  async function confirmResult(fields: any) {
    if (!analysis?.result) return;
    try {
      const r = await api<any>("/api/results", {
        method: "PATCH",
        body: JSON.stringify({ id: analysis.result.id, action: "confirm", ...fields }),
      });
      if (r.status === "verified") {
        fx.toast("Result verified! XP awarded.", "ok");
        fx.popXp(r.xpAwarded);
        reload();
      } else {
        fx.toast(r.message || "Sent to manual review.", "info");
      }
      setAnalysis(null);
      loadResults();
    } catch (err: any) {
      fx.toast(err.message, "bad");
    }
  }

  async function cancelResult() {
    if (!analysis?.result) return;
    try {
      await api("/api/results", {
        method: "PATCH",
        body: JSON.stringify({ id: analysis.result.id, action: "cancel" }),
      });
      fx.toast("Submission cancelled.", "info");
    } catch {
      /* noop */
    }
    setAnalysis(null);
    loadResults();
  }

  async function claim(g: any) {
    try {
      await api("/api/gifts", { method: "PATCH", body: JSON.stringify({ giftId: g.id }) });
      setGifts((gs) => gs.map((x) => (x.id === g.id ? { ...x, claimed: true } : x)));
      setUnread((u) => Math.max(0, u - 1));
      fx.giftOpen({ roleName: g.roleName, color: g.roleColor, glow: g.roleColor, badge: g.roleBadge });
      reload();
    } catch (err: any) {
      fx.toast(err.message, "bad");
    }
  }

  async function redeem(e: React.FormEvent) {
    e.preventDefault();
    try {
      const r = await api<any>("/api/codes/redeem", { method: "POST", body: JSON.stringify({ code }) });
      fx.toast(r.message, "gold");
      fx.popXp(r.awarded);
      setCode("");
      reload();
    } catch (err: any) {
      fx.toast(err.message, "bad");
    }
  }

  if (loading || !user) {
    return (
      <main style={{ minHeight: "100vh", display: "grid", placeItems: "center" }}>
        <Spinner />
      </main>
    );
  }

  return (
    <main className="page-in" style={{ minHeight: "100vh", padding: "1rem clamp(1rem,4vw,2.4rem)" }}>
      {/* Top bar */}
      <header
        className="glass hud"
        style={{ display: "flex", alignItems: "center", gap: 14, padding: "0.7rem 1rem", flexWrap: "wrap", position: "sticky", top: 10, zIndex: 20 }}
      >
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 8, textDecoration: "none", color: "var(--text)" }}>
          <div className="rank-orb fx-glow" style={{ width: 34, height: 34, fontSize: ".9rem", "--rk-color": "#22d3ee", "--rk-glow": "#4f7bff" } as React.CSSProperties}>A</div>
          <span style={{ fontFamily: "Orbitron", fontWeight: 800, letterSpacing: ".16em" }}>AURORA</span>
        </Link>
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap", minWidth: 160 }}>
          <Avatar seed={user.username} size={38} />
          <div>
            <div style={{ fontWeight: 700 }}>{user.username}</div>
            <RankBadge role={user.role} />
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
          <Link className="btn btn-ghost" href="/scoreboard" style={{ fontSize: ".68rem" }}>Scoreboard</Link>
          <Link className="btn btn-ghost" href="/portfolio" style={{ fontSize: ".68rem" }}>Portfolio</Link>
          {user.isAdmin && (
            <Link className="btn btn-gold" href="/admin" style={{ fontSize: ".68rem" }}>Admin</Link>
          )}
          <button className="btn" onClick={() => setGiftModal(true)} style={{ position: "relative", fontSize: ".78rem" }}>
            🎁 Gift Box
            {unread > 0 && (
              <span style={{ position: "absolute", top: -8, right: -8, background: "var(--danger)", color: "#fff", borderRadius: 999, fontSize: ".65rem", minWidth: 18, height: 18, display: "grid", placeItems: "center", padding: "0 4px" }}>{unread}</span>
            )}
          </button>
          <button className="btn btn-ghost" onClick={logout} style={{ fontSize: ".68rem" }}>Logout</button>
        </div>
      </header>

      <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr)", gap: 18, marginTop: 18, maxWidth: 1200, margin: "18px auto 0" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))", gap: 18 }}>
          {/* Profile card */}
          <section className="glass hud neon-edge" style={{ padding: "1.4rem", display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}>
            <RankOrb role={user.role} size={120} label />
            <div style={{ width: "100%" }}>
              <XpBar progress={user.progress} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8, width: "100%" }}>
              <Stat label="Level" value={user.level} />
              <Stat label="Tests" value={user.testsCount} />
              <Stat label="Verified" value={user.verifiedCount} />
            </div>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "center", marginTop: 4 }}>
              <Toggle on={fx.sound} onChange={fx.setSound} label="Sound" />
              <Toggle on={fx.perf} onChange={fx.setPerf} label="Perf" />
              <Toggle on={fx.reduced} onChange={fx.setReduced} label="Motion" />
            </div>
          </section>

          {/* Upload + Redeem */}
          <section style={{ display: "grid", gap: 18 }}>
            <div className="glass hud" style={{ padding: "1.3rem" }}>
              <h2 style={{ fontFamily: "Orbitron", fontSize: ".85rem", letterSpacing: ".1em", margin: "0 0 12px" }}>📤 UPLOAD TEST RESULT</h2>
              <form onSubmit={onUpload} style={{ display: "grid", gap: 10 }} encType="multipart/form-data">
                <input className="field" type="file" name="file" accept="image/jpeg,image/png,image/webp" required />
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <input className="field" name="subject" placeholder="Subject (optional)" />
                  <input className="field" name="testName" placeholder="Test name (optional)" />
                  <input className="field" name="marks" type="number" min="0" placeholder="Marks" />
                  <input className="field" name="maxMarks" type="number" min="1" placeholder="Max marks" />
                </div>
                <p style={{ color: "var(--muted)", fontSize: ".74rem", margin: 0 }}>
                  Tip: entering marks lets the analyzer auto-verify instantly (+XP & image bonus). Image-only uploads go to manual review.
                </p>
                <button className="btn btn-primary" disabled={uploading} style={{ justifyContent: "center" }}>
                  {uploading ? <Spinner /> : "Analyze & Submit"}
                </button>
              </form>
            </div>

            <div className="glass hud" style={{ padding: "1.3rem" }}>
              <h2 style={{ fontFamily: "Orbitron", fontSize: ".85rem", letterSpacing: ".1em", margin: "0 0 12px" }}>🎟️ REDEEM XP CODE</h2>
              <form onSubmit={redeem} style={{ display: "flex", gap: 8 }}>
                <input className="field" value={code} onChange={(e) => setCode(e.target.value)} placeholder="Enter XP code" />
                <button className="btn btn-gold">Redeem</button>
              </form>
            </div>
          </section>
        </div>

        {/* Recent results */}
        <section className="glass hud" style={{ padding: "1.3rem", marginTop: 0 }}>
          <h2 style={{ fontFamily: "Orbitron", fontSize: ".85rem", letterSpacing: ".1em", margin: "0 0 12px" }}>RECENT RESULTS</h2>
          {results.length === 0 ? (
            <p style={{ color: "var(--muted)", fontSize: ".85rem" }}>No results yet. Upload your first test result above.</p>
          ) : (
            <div style={{ overflowX: "auto" }}>
              <table className="tbl">
                <thead><tr><th>Subject</th><th>Marks</th><th>%</th><th>Conf.</th><th>Status</th><th>When</th></tr></thead>
                <tbody>
                  {results.map((r) => (
                    <tr key={r.id}>
                      <td>{r.subject || "—"}</td>
                      <td>{r.marksObtained != null ? `${r.marksObtained}/${r.maxMarks ?? "?"}` : "—"}</td>
                      <td>{r.percentage != null ? `${r.percentage}%` : "—"}</td>
                      <td>{r.confidence ?? "—"}%</td>
                      <td><StatusPill status={r.status} /></td>
                      <td style={{ color: "var(--muted)", fontSize: ".78rem" }}>{new Date(r.createdAt).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>

      {giftModal && (
        <Modal title="🎁 Gift Box" onClose={() => setGiftModal(false)}>
          {gifts.length === 0 ? (
            <p style={{ color: "var(--muted)" }}>Your gift box is empty. Admins can send you special roles here.</p>
          ) : (
            <div style={{ display: "grid", gap: 10 }}>
              {gifts.map((g) => (
                <div key={g.id} className="glass" style={{ padding: "0.9rem", display: "flex", alignItems: "center", gap: 12, borderColor: g.claimed ? undefined : g.roleColor }}>
                  <div className="rank-orb fx-glow" style={{ width: 46, height: 46, fontSize: "1.1rem", "--rk-color": g.roleColor, "--rk-glow": g.roleColor } as React.CSSProperties}>{g.roleBadge}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700 }}>{g.message}</div>
                    <div style={{ color: "var(--muted)", fontSize: ".76rem" }}>{new Date(g.createdAt).toLocaleString()}</div>
                  </div>
                  {g.claimed ? (
                    <span className="rank-badge" style={{ "--rk-color": "var(--ok)", "--rk-glow": "var(--ok)" } as React.CSSProperties}>Claimed</span>
                  ) : (
                    <button className="btn btn-gold" onClick={() => claim(g)}>Claim</button>
                  )}
                </div>
              ))}
            </div>
          )}
        </Modal>
      )}

      {analysis && <AnalysisModal analysis={analysis} onConfirm={confirmResult} onCancel={cancelResult} onClose={() => { setAnalysis(null); loadResults(); }} />}
    </main>
  );
}

function StatusPill({ status }: { status: string }) {
  const map: Record<string, { c: string; t: string }> = {
    verified: { c: "var(--ok)", t: "Verified" },
    pending: { c: "var(--warn)", t: "Review" },
    duplicate: { c: "var(--danger)", t: "Duplicate" },
    rejected: { c: "var(--danger)", t: "Rejected" },
  };
  const m = map[status] || { c: "var(--muted)", t: status };
  return <span className="rank-badge" style={{ "--rk-color": m.c, "--rk-glow": m.c } as React.CSSProperties}>{m.t}</span>;
}

function AnalysisModal({
  analysis,
  onConfirm,
  onCancel,
  onClose,
}: {
  analysis: any;
  onConfirm: (fields: any) => void;
  onCancel: () => void;
  onClose: () => void;
}) {
  const a = analysis.analysis || {};
  const [subject, setSubject] = useState(a.subject || "");
  const [marks, setMarks] = useState(a.marksObtained ?? "");
  const [maxMarks, setMaxMarks] = useState(a.maxMarks ?? "");
  const dup = analysis.possibleDuplicate;

  return (
    <Modal title="🔬 ANALYSIS RESULT" onClose={onClose} width={520}>
      {analysis.result?.imageDataUrl && (
        <img src={analysis.result.imageDataUrl} alt="upload" style={{ width: "100%", borderRadius: 12, marginBottom: 12, border: "1px solid var(--border)" }} />
      )}
      {dup && (
        <div style={{ background: "rgba(255,176,32,.12)", border: "1px solid var(--warn)", borderRadius: 10, padding: "0.6rem 0.8rem", color: "var(--warn)", fontSize: ".8rem", marginBottom: 12 }}>
          ⚠️ POSSIBLE DUPLICATE — this image looks similar to a previous submission. It will be sent to admin review.
        </div>
      )}
      <div style={{ display: "grid", gap: 10 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <div><label className="label">Subject</label><input className="field" value={subject} onChange={(e) => setSubject(e.target.value)} /></div>
          <div><label className="label">Marks</label><input className="field" type="number" value={marks} onChange={(e) => setMarks(e.target.value)} /></div>
          <div><label className="label">Max marks</label><input className="field" type="number" value={maxMarks} onChange={(e) => setMaxMarks(e.target.value)} /></div>
          <div><label className="label">Confidence</label><div className="field" style={{ color: "var(--neon-2)" }}>{a.confidence}%</div></div>
        </div>
        {a.percentage != null && (
          <div style={{ color: "var(--muted)", fontSize: ".85rem" }}>Detected percentage: <b style={{ color: "var(--ok)" }}>{a.percentage}%</b></div>
        )}
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 6 }}>
          <button className="btn btn-ghost" onClick={onCancel}>Cancel</button>
          <button className="btn btn-primary" onClick={() => onConfirm({ subject, marks: marks === "" ? null : Number(marks), maxMarks: maxMarks === "" ? null : Number(maxMarks) })}>Confirm</button>
        </div>
      </div>
    </Modal>
  );
}
