"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/client";
import { Modal, Spinner } from "@/components/ui";

export default function Portfolio() {
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<any | null>(null);

  useEffect(() => {
    api<{ projects: any[] }>("/api/portfolio")
      .then((r) => setProjects(r.projects))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <main className="page-in" style={{ minHeight: "100vh", padding: "1.4rem clamp(1rem,4vw,3rem)" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12, marginBottom: 28 }}>
        <div>
          <h1 style={{ fontFamily: "Orbitron", letterSpacing: ".12em", fontSize: "clamp(1.4rem,4vw,2.2rem)", margin: 0 }}>PORTFOLIO</h1>
          <p style={{ color: "var(--muted)", margin: "4px 0 0" }}>Selected projects, apps and AI experiments.</p>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <Link className="btn btn-ghost" href="/">Home</Link>
          <Link className="btn btn-ghost" href="/scoreboard">Scoreboard</Link>
          <Link className="btn btn-primary" href="/dashboard">Dashboard</Link>
        </div>
      </header>

      {loading ? (
        <div style={{ display: "grid", placeItems: "center", padding: 60 }}><Spinner /></div>
      ) : projects.length === 0 ? (
        <p style={{ color: "var(--muted)" }}>No projects published yet.</p>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(300px,1fr))", gap: 18 }}>
          {projects.map((p) => (
            <article key={p.id} className="glass card-hover hud" style={{ padding: 0, overflow: "hidden", cursor: "pointer", display: "flex", flexDirection: "column" }} onClick={() => setActive(p)}>
              <div style={{ position: "relative", aspectRatio: "16/10", background: "#0a0e22" }}>
                {p.imageUrl ? (
                  <img src={p.imageUrl} alt={p.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} loading="lazy" />
                ) : (
                  <div style={{ width: "100%", height: "100%", display: "grid", placeItems: "center", color: "var(--muted)" }}>No preview</div>
                )}
                {p.featured && (
                  <span style={{ position: "absolute", top: 10, left: 10, background: "linear-gradient(120deg,#ffd24a,#ff9e2c)", color: "#2a1c00", fontFamily: "Orbitron", fontSize: ".62rem", padding: "3px 8px", borderRadius: 999, letterSpacing: ".1em" }}>★ FEATURED</span>
                )}
                <span style={{ position: "absolute", top: 10, right: 10, background: "rgba(8,12,30,.8)", border: "1px solid var(--border)", color: "var(--neon-2)", fontFamily: "Orbitron", fontSize: ".6rem", padding: "3px 8px", borderRadius: 999 }}>{p.category}</span>
              </div>
              <div style={{ padding: "1rem 1.1rem 1.2rem", display: "flex", flexDirection: "column", gap: 8, flex: 1 }}>
                <h3 style={{ margin: 0, fontFamily: "Orbitron", fontSize: "1rem", letterSpacing: ".04em" }}>{p.name}</h3>
                <p style={{ margin: 0, color: "var(--muted)", fontSize: ".84rem", flex: 1 }}>{p.description}</p>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 4 }}>
                  {(p.technologies || []).slice(0, 4).map((t: string) => (
                    <span key={t} style={{ fontSize: ".66rem", padding: "2px 8px", borderRadius: 999, background: "rgba(79,123,255,.15)", border: "1px solid var(--border)", color: "var(--neon-2)", fontFamily: "Orbitron" }}>{t}</span>
                  ))}
                </div>
                <button className="btn btn-primary" style={{ marginTop: 8 }}>View Project</button>
              </div>
            </article>
          ))}
        </div>
      )}

      {active && <ProjectModal project={active} onClose={() => setActive(null)} />}
    </main>
  );
}

function ProjectModal({ project, onClose }: { project: any; onClose: () => void }) {
  const shots: string[] = Array.isArray(project.screenshots) ? project.screenshots : [];
  const [img, setImg] = useState(project.imageUrl || shots[0] || "");
  return (
    <Modal title={project.name} onClose={onClose} width={720}>
      <div style={{ display: "grid", gap: 14 }}>
        <img src={img} alt={project.name} style={{ width: "100%", borderRadius: 12, border: "1px solid var(--border)", aspectRatio: "16/9", objectFit: "cover" }} />
        {shots.length > 1 && (
          <div style={{ display: "flex", gap: 8, overflowX: "auto" }} className="no-scrollbar">
            {shots.map((s) => (
              <img key={s} src={s} alt="screenshot" onClick={() => setImg(s)} style={{ height: 64, borderRadius: 8, border: img === s ? "2px solid var(--neon)" : "1px solid var(--border)", cursor: "pointer" }} />
            ))}
          </div>
        )}
        <p style={{ color: "var(--muted)", margin: 0 }}>{project.description}</p>
        {Array.isArray(project.features) && project.features.length > 0 && (
          <div>
            <div className="label">Features</div>
            <ul style={{ margin: 0, paddingLeft: 18, color: "var(--text)", fontSize: ".88rem" }}>
              {project.features.map((f: string) => <li key={f}>{f}</li>)}
            </ul>
          </div>
        )}
        <div>
          <div className="label">Technologies</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {(project.technologies || []).map((t: string) => (
              <span key={t} style={{ fontSize: ".7rem", padding: "3px 10px", borderRadius: 999, background: "rgba(79,123,255,.15)", border: "1px solid var(--border)", color: "var(--neon-2)", fontFamily: "Orbitron" }}>{t}</span>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {project.liveDemoUrl && project.liveDemoUrl !== "#" && <a className="btn btn-primary" href={project.liveDemoUrl} target="_blank" rel="noreferrer">▶ Live Demo</a>}
          {project.sourceCodeUrl && project.sourceCodeUrl !== "#" && <a className="btn" href={project.sourceCodeUrl} target="_blank" rel="noreferrer">⌘ Source Code</a>}
        </div>
      </div>
    </Modal>
  );
}
