"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/client";
import { RankBadge, RankOrb, Spinner, Avatar } from "@/components/ui";

const METRICS = [
  { k: "xp", l: "Total XP" },
  { k: "level", l: "Level" },
  { k: "verified", l: "Verified Tests" },
  { k: "average", l: "Avg %" },
];

export default function Scoreboard() {
  const [board, setBoard] = useState<any[]>([]);
  const [metric, setMetric] = useState("xp");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    api<{ board: any[] }>(`/api/scoreboard?metric=${metric}`)
      .then((r) => active && setBoard(r.board))
      .catch(() => {})
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [metric]);

  const valOf = (i: any) =>
    metric === "xp"
      ? `${i.xp.toLocaleString()} XP`
      : metric === "level"
      ? `Level ${i.level}`
      : metric === "verified"
      ? `${i.verified} verified`
      : `${i.avgPct}% avg`;

  const top3 = board.slice(0, 3);
  const rest = board.slice(3);
  const podiumOrder = [top3[1], top3[0], top3[2]].filter(Boolean);

  return (
    <main className="page-in" style={{ minHeight: "100vh", padding: "1.4rem clamp(1rem,4vw,3rem)" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12, marginBottom: 24 }}>
        <div>
          <h1 style={{ fontFamily: "Orbitron", letterSpacing: ".12em", fontSize: "clamp(1.4rem,4vw,2.2rem)", margin: 0 }}>ACADEMIC SCOREBOARD</h1>
          <p style={{ color: "var(--muted)", margin: "4px 0 0" }}>Global rankings by {METRICS.find((m) => m.k === metric)?.l.toLowerCase()}.</p>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <Link className="btn btn-ghost" href="/">Home</Link>
          <Link className="btn btn-ghost" href="/portfolio">Portfolio</Link>
          <Link className="btn btn-primary" href="/dashboard">Dashboard</Link>
        </div>
      </header>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 22 }}>
        {METRICS.map((m) => (
          <button key={m.k} className="btn" onClick={() => setMetric(m.k)} style={{ background: metric === m.k ? "linear-gradient(120deg,#2b4bff,#22d3ee)" : undefined, color: metric === m.k ? "#02040c" : undefined, border: "none" }}>
            {m.l}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ display: "grid", placeItems: "center", padding: 60 }}><Spinner /></div>
      ) : board.length === 0 ? (
        <p style={{ color: "var(--muted)" }}>No pilots ranked yet.</p>
      ) : (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 16, maxWidth: 760, margin: "0 auto 30px", alignItems: "end" }}>
            {podiumOrder.map((p, idx) => {
              const realRank = top3.indexOf(p) + 1;
              const size = realRank === 1 ? 110 : 86;
              return (
                <div key={p.id} className="glass hud card-hover" style={{ padding: "1.2rem", textAlign: "center", order: idx, transform: realRank === 1 ? "translateY(-10px)" : undefined }}>
                  <div style={{ fontFamily: "Orbitron", fontSize: "1.6rem", color: realRank === 1 ? "var(--gold)" : "var(--muted)" }}>#{realRank}</div>
                  <div style={{ margin: "10px auto" }}><RankOrb role={p.role} size={size} /></div>
                  <div style={{ fontWeight: 700 }}>{p.username}</div>
                  <RankBadge role={p.role} className="" />
                  <div style={{ color: "var(--neon-2)", fontFamily: "Orbitron", fontSize: ".8rem", marginTop: 6 }}>{valOf(p)}</div>
                </div>
              );
            })}
          </div>

          <div className="glass hud" style={{ padding: "0.4rem 1rem", maxWidth: 860, margin: "0 auto" }}>
            <table className="tbl">
              <thead><tr><th>#</th><th>Pilot</th><th>Rank</th><th>Level</th><th>Value</th></tr></thead>
              <tbody>
                {rest.map((p, i) => (
                  <tr key={p.id}>
                    <td style={{ color: "var(--muted)", fontFamily: "Orbitron" }}>{i + 4}</td>
                    <td><div style={{ display: "flex", alignItems: "center", gap: 10 }}><Avatar seed={p.username} size={30} /><span>{p.username}</span></div></td>
                    <td><RankBadge role={p.role} /></td>
                    <td>{p.level}</td>
                    <td style={{ color: "var(--neon-2)", fontFamily: "Orbitron" }}>{valOf(p)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </main>
  );
}
