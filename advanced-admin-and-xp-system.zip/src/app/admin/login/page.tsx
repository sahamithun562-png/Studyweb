"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "@/lib/client";
import { useFx } from "@/components/fx";
import { Spinner, useSession } from "@/components/ui";

export default function AdminLoginPage() {
  const [username, setUsername] = useState("owner");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();
  const { toast } = useFx();
  const { user, loading: sessLoading } = useSession();

  useEffect(() => {
    if (!sessLoading && user?.isAdmin) router.replace("/admin");
  }, [sessLoading, user, router]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setErr("");
    try {
      await api("/api/admin/login", { method: "POST", body: JSON.stringify({ username, password }) });
      toast("Administrator authenticated.", "ok");
      router.push("/admin");
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="admin-shell" style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: "2rem 1rem" }}>
      <div className="glass-solid hud neon-edge" style={{ width: 440, maxWidth: "94vw", padding: "2rem" }}>
        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <div className="rank-orb fx-glow" style={{ margin: "0 auto", width: 64, height: 64, fontSize: "1.4rem", "--rk-color": "#ff4d6d", "--rk-glow": "#ff8a3d" } as React.CSSProperties}>⚠</div>
          <h1 style={{ fontFamily: "Orbitron", letterSpacing: ".16em", margin: "12px 0 4px", fontSize: "1.2rem" }}>ADMIN ACCESS</h1>
          <p style={{ color: "var(--muted)", fontSize: ".82rem" }}>Authorized administrators only. All access is logged.</p>
        </div>
        <form onSubmit={submit} style={{ display: "grid", gap: 14 }}>
          <div>
            <label className="label">Administrator Username</label>
            <input className="field" value={username} onChange={(e) => setUsername(e.target.value)} />
          </div>
          <div>
            <label className="label">Password</label>
            <input className="field" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
          </div>
          {err && <div style={{ color: "var(--danger)", fontSize: ".82rem" }}>{err}</div>}
          <button className="btn btn-danger" disabled={loading} style={{ padding: "0.8rem" }}>
            {loading ? <Spinner /> : "🔓 Authenticate"}
          </button>
        </form>
        <div style={{ textAlign: "center", marginTop: 16 }}>
          <Link className="btn btn-ghost" href="/" style={{ fontSize: ".7rem" }}>← Back to site</Link>
        </div>
      </div>
    </main>
  );
}
