"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client";
import { useFx } from "@/components/fx";
import {
  Avatar,
  RankBadge,
  RankOrb,
  Spinner,
  Stat,
  Modal,
  useSession,
} from "@/components/ui";
import { xpAtLevel } from "@/lib/xp";

const SECTIONS = [
  { k: "dashboard", l: "Dashboard", i: "▦" },
  { k: "users", l: "User Management", i: "👥" },
  { k: "results", l: "Results", i: "📄" },
  { k: "analyzer", l: "Image Analyzer", i: "🔬" },
  { k: "duplicates", l: "Duplicate Detection", i: "🧬" },
  { k: "xp", l: "XP Control", i: "⚡" },
  { k: "levels", l: "Level Management", i: "📊" },
  { k: "roles", l: "Role Management", i: "🏅" },
  { k: "gifts", l: "Gift Management", i: "🎁" },
  { k: "codes", l: "XP Codes", i: "🎟️" },
  { k: "scoreboard", l: "Scoreboard", i: "🏆" },
  { k: "audit", l: "Audit Logs", i: "📜" },
  { k: "settings", l: "Settings", i: "⚙️" },
  { k: "portfolio", l: "Portfolio", i: "💼" },
] as const;

function numPrompt(msg: string): number | null {
  const v = window.prompt(msg);
  if (v === null) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function useFetch<T>(path: string | null, deps: any[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(!!path);
  const [err, setErr] = useState("");
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const reload = useCallback(() => {
    if (!path) return;
    setLoading(true);
    api<T>(path)
      .then((d) => {
        setData(d);
        setErr("");
      })
      .catch((e) => setErr(e.message))
      .finally(() => setLoading(false));
  }, [path, ...deps]);
  useEffect(() => {
    reload();
  }, [reload]);
  return { data, loading, err, reload };
}

function H({ children }: { children: React.ReactNode }) {
  return <h2 style={{ fontFamily: "Orbitron", fontSize: ".9rem", letterSpacing: ".1em", margin: "0 0 14px" }}>{children}</h2>;
}

function Err({ m }: { m: string }) {
  return m ? <div style={{ color: "var(--danger)", marginBottom: 10 }}>{m}</div> : null;
}

export default function AdminPage() {
  const { user, loading } = useSession();
  const router = useRouter();
  const fx = useFx();
  const [section, setSection] = useState<string>("dashboard");

  useEffect(() => {
    if (!loading && (!user || !user.isAdmin)) router.replace("/admin/login");
  }, [loading, user, router]);

  async function logout() {
    try {
      await api("/api/admin/logout", { method: "POST", body: JSON.stringify({}) });
    } catch {
      /* noop */
    }
    router.push("/admin/login");
  }

  if (loading || !user) {
    return (
      <main style={{ minHeight: "100vh", display: "grid", placeItems: "center" }}>
        <Spinner />
      </main>
    );
  }

  return (
    <main className="admin-shell page-in" style={{ minHeight: "100vh", padding: "1rem clamp(0.6rem,2vw,1.6rem)" }}>
      <header className="glass hud" style={{ display: "flex", alignItems: "center", gap: 12, padding: "0.7rem 1rem", flexWrap: "wrap", position: "sticky", top: 8, zIndex: 20 }}>
        <span style={{ fontFamily: "Orbitron", fontWeight: 800, letterSpacing: ".14em", color: "var(--neon)" }}>◆ ADMIN COMMAND</span>
        <span style={{ color: "var(--muted)", fontSize: ".8rem" }}>· {user.username}{user.isOwner ? " (OWNER)" : ""}</span>
        <div style={{ flex: 1 }} />
        <Link className="btn btn-ghost" href="/" style={{ fontSize: ".68rem" }}>View Site</Link>
        <button className="btn btn-danger" onClick={logout} style={{ fontSize: ".68rem" }}>Logout</button>
      </header>

      <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr)", gap: 16, maxWidth: 1280, margin: "16px auto 0" }}>
        <nav className="glass" style={{ display: "flex", gap: 6, padding: 8, overflowX: "auto" }} >
          {SECTIONS.map((s) => (
            <button key={s.k} className="btn btn-ghost" onClick={() => setSection(s.k)} style={{
              fontSize: ".68rem", whiteSpace: "nowrap",
              background: section === s.k ? "linear-gradient(120deg,#ff2d55,#ff8a3d)" : undefined,
              color: section === s.k ? "#1a0207" : undefined, border: "none",
            }}>
              {s.i} {s.l}
            </button>
          ))}
        </nav>

        <section key={section} className="page-in">
          {section === "dashboard" && <DashboardSection fx={fx} />}
          {section === "users" && <UsersSection fx={fx} />}
          {section === "results" && <ResultsSection fx={fx} initialStatus="" />}
          {section === "analyzer" && <ResultsSection fx={fx} initialStatus="" big />}
          {section === "duplicates" && <ResultsSection fx={fx} initialStatus="duplicate" />}
          {section === "xp" && <XpSection fx={fx} />}
          {section === "levels" && <LevelsSection fx={fx} />}
          {section === "roles" && <RolesSection fx={fx} />}
          {section === "gifts" && <GiftsSection fx={fx} />}
          {section === "codes" && <CodesSection fx={fx} />}
          {section === "scoreboard" && <ScoreboardSection />}
          {section === "audit" && <AuditSection />}
          {section === "settings" && <SettingsSection fx={fx} />}
          {section === "portfolio" && <PortfolioSection fx={fx} />}
        </section>
      </div>
    </main>
  );
}

type FX = ReturnType<typeof useFx>;

/* ---------------- Dashboard ---------------- */
function DashboardSection({ fx }: { fx: FX }) {
  const { data, loading, err } = useFetch<any>("/api/admin/dashboard");
  if (loading) return <Spinner />;
  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <H>System Overview</H>
      <Err m={err} />
      {data && (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(140px,1fr))", gap: 12 }}>
            <Stat label="Users" value={data.stats.users} />
            <Stat label="Blocked" value={data.stats.blocked} />
            <Stat label="Results" value={data.stats.results} />
            <Stat label="Verified" value={data.stats.verified} />
            <Stat label="Pending Review" value={data.stats.pending} />
            <Stat label="Duplicates" value={data.stats.duplicate} />
            <Stat label="XP Codes" value={data.stats.codes} />
            <Stat label="Unclaimed Gifts" value={data.stats.unclaimedGifts} />
          </div>
          <div style={{ marginTop: 18 }}>
            <div className="label">Recent Activity</div>
            <div style={{ display: "grid", gap: 6 }}>
              {(data.recent || []).map((a: any) => (
                <div key={a.id} style={{ fontSize: ".82rem", display: "flex", gap: 10, padding: "6px 8px", borderBottom: "1px solid rgba(255,255,255,.06)" }}>
                  <span style={{ color: "var(--neon)", fontFamily: "Orbitron", fontSize: ".66rem" }}>{a.action}</span>
                  <span style={{ flex: 1 }}>{a.details}</span>
                  <span style={{ color: "var(--muted)", fontSize: ".72rem" }}>{new Date(a.createdAt).toLocaleString()}</span>
                </div>
              ))}
              {(!data.recent || data.recent.length === 0) && <p style={{ color: "var(--muted)" }}>No activity yet.</p>}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

/* ---------------- Users ---------------- */
function UsersSection({ fx }: { fx: FX }) {
  const { data, loading, err, reload } = useFetch<any>("/api/admin/users");
  const [detail, setDetail] = useState<any | null>(null);
  if (loading) return <Spinner />;
  const users: any[] = data?.users || [];
  const roles: any[] = data?.roles || [];
  const selfId = data?.selfId;

  async function act(userId: string, action: string, value?: any, ok?: string) {
    try {
      const r = await api<any>("/api/admin/users", { method: "PATCH", body: JSON.stringify({ id: userId, action, value }) });
      fx.toast(ok || "Updated.", "ok");
      if (r?.user?.leveledUp) fx.toast(`${r.user.username} leveled up!`, "gold");
      reload();
    } catch (e: any) {
      fx.toast(e.message, "bad");
    }
  }

  async function setRole(userId: string) {
    // open detail instead
    setDetail(users.find((u) => u.id === userId) ?? null);
  }

  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <H>User / Visitor Management</H>
      <Err m={err} />
      <div style={{ overflowX: "auto" }}>
        <table className="tbl">
          <thead>
            <tr>
              <th>User</th><th>Level</th><th>XP</th><th>Rank</th><th>Status</th><th>Tests</th><th>Verified</th><th>Last Active</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => {
              const protectedUser = u.isOwner || u.id === selfId;
              return (
                <tr key={u.id}>
                  <td><div style={{ display: "flex", alignItems: "center", gap: 8 }}><Avatar seed={u.username} size={30} /><div><div style={{ fontWeight: 600 }}>{u.username}{u.isOwner && " 👑"}</div><div style={{ fontSize: ".68rem", color: "var(--muted)" }}>{new Date(u.createdAt).toLocaleDateString()}</div></div></div></td>
                  <td>{u.level}</td>
                  <td>{u.xp.toLocaleString()}</td>
                  <td><RankBadge role={u.role} /></td>
                  <td>{u.status === "blocked" ? <span style={{ color: "var(--danger)" }}>Blocked</span> : <span style={{ color: "var(--ok)" }}>Active</span>}</td>
                  <td>{u.testsCount}</td>
                  <td>{u.verifiedCount}</td>
                  <td style={{ color: "var(--muted)", fontSize: ".74rem" }}>{new Date(u.lastActiveAt).toLocaleDateString()}</td>
                  <td>
                    <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                      {u.status === "blocked" ? (
                        <button className="btn" style={{ fontSize: ".6rem" }} onClick={() => act(u.id, "unblock", undefined, "User unblocked.")}>Unblock</button>
                      ) : (
                        <button className="btn btn-danger" style={{ fontSize: ".6rem" }} disabled={protectedUser} title={protectedUser ? "You cannot block your own administrator account." : ""} onClick={() => act(u.id, "block", undefined, "User blocked.")}>Block</button>
                      )}
                      <button className="btn" style={{ fontSize: ".6rem" }} onClick={() => { const n = numPrompt(`Set level for ${u.username}:`); if (n != null) act(u.id, "setLevel", n, "Level updated."); }}>Level</button>
                      <button className="btn" style={{ fontSize: ".6rem" }} onClick={() => { const n = numPrompt(`Set exact XP for ${u.username}:`); if (n != null) act(u.id, "setXp", n, "XP updated."); }}>XP</button>
                      <button className="btn" style={{ fontSize: ".6rem" }} onClick={() => { const n = numPrompt(`Add XP to ${u.username}:`); if (n != null) act(u.id, "addXp", n, "XP added."); }}>+XP</button>
                      <button className="btn" style={{ fontSize: ".6rem" }} onClick={() => setRole(u.id)}>Manage</button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {detail && <UserDetail fx={fx} userId={detail.id} roles={roles} onClose={() => setDetail(null)} onChanged={reload} />}
    </div>
  );
}

function UserDetail({ fx, userId, roles, onClose, onChanged }: { fx: FX; userId: string; roles: any[]; onClose: () => void; onChanged: () => void }) {
  const { data, loading, reload } = useFetch<any>(`/api/admin/users/${userId}`);
  if (loading || !data) return <Modal title="Loading" onClose={onClose}><Spinner /></Modal>;
  const p = data.profile;
  async function act(action: string, value?: any, ok?: string) {
    try { await api("/api/admin/users", { method: "PATCH", body: JSON.stringify({ id: userId, action, value }) }); fx.toast(ok || "Updated.", "ok"); reload(); onChanged(); } catch (e: any) { fx.toast(e.message, "bad"); }
  }
  return (
    <Modal title={`Manage @${p.username}`} onClose={onClose} width={680}>
      <div style={{ display: "grid", gap: 16 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
          <RankOrb role={p.role} size={70} />
          <div>
            <div style={{ fontWeight: 700 }}>{p.username} {p.isOwner && "👑"}</div>
            <RankBadge role={p.role} />
            <div style={{ color: "var(--muted)", fontSize: ".78rem" }}>Level {p.level} · {p.xp.toLocaleString()} XP · {p.testsCount} tests · {p.verifiedCount} verified · {p.avgPct}% avg</div>
          </div>
        </div>

        <div>
          <div className="label">XP Control</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => { const n = numPrompt("Add XP:"); if (n != null) act("addXp", n, "XP added."); }}>+ Add XP</button>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => { const n = numPrompt("Remove XP:"); if (n != null) act("removeXp", n, "XP removed."); }}>− Remove XP</button>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => { const n = numPrompt("Set exact XP:"); if (n != null) act("setXp", n, "XP set."); }}>Set XP</button>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => { const n = numPrompt("Set exact level:"); if (n != null) act("setLevel", n, "Level set."); }}>Set Level</button>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => act("resetXp", undefined, "XP reset.")}>Reset XP</button>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => act("resetLevel", undefined, "Level reset.")}>Reset Level</button>
          </div>
        </div>

        <div>
          <div className="label">Role Control</div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
            <select className="field" style={{ width: "auto" }} defaultValue={p.role?.id === (data.roles?.find?.((r: any) => r.id === p.manualRoleId)?.id) ? p.manualRoleId : ""} onChange={(e) => act("setRole", e.target.value || null, "Role updated.")}>
              <option value="">— Auto / none —</option>
              {(roles).map((r: any) => <option key={r.id} value={r.id}>{r.name} (Lvl {r.levelRequirement})</option>)}
            </select>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => act("clearRole", undefined, "Manual role cleared.")}>Clear Manual</button>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => act("clearGiftRole", undefined, "Gifted role removed.")}>Remove Gift</button>
          </div>
        </div>

        <div>
          <div className="label">XP History</div>
          <div style={{ maxHeight: 140, overflow: "auto", border: "1px solid var(--border)", borderRadius: 10 }}>
            {(data.xpHistory || []).map((h: any) => (
              <div key={h.id} style={{ display: "flex", justifyContent: "space-between", padding: "5px 9px", fontSize: ".78rem", borderBottom: "1px solid rgba(255,255,255,.05)" }}>
                <span>{h.reason}</span>
                <span style={{ color: h.amount >= 0 ? "var(--ok)" : "var(--danger)" }}>{h.amount >= 0 ? "+" : ""}{h.amount} → {h.balanceAfter.toLocaleString()}</span>
              </div>
            ))}
            {(!data.xpHistory || data.xpHistory.length === 0) && <div style={{ padding: 10, color: "var(--muted)", fontSize: ".8rem" }}>No XP history.</div>}
          </div>
        </div>

        <div>
          <div className="label">Submitted Results ({(data.results || []).length})</div>
          <div style={{ maxHeight: 140, overflow: "auto", border: "1px solid var(--border)", borderRadius: 10 }}>
            {(data.results || []).map((r: any) => (
              <div key={r.id} style={{ display: "flex", justifyContent: "space-between", padding: "5px 9px", fontSize: ".78rem", borderBottom: "1px solid rgba(255,255,255,.05)" }}>
                <span>{r.subject || "—"} · {r.marksObtained != null ? `${r.marksObtained}/${r.maxMarks ?? "?"}` : "—"}</span>
                <span style={{ color: "var(--muted)" }}>{r.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
}

/* ---------------- Results / Analyzer / Duplicates ---------------- */
function ResultsSection({ fx, initialStatus, big }: { fx: FX; initialStatus: string; big?: boolean }) {
  const [status, setStatus] = useState(initialStatus);
  const { data, loading, err, reload } = useFetch<any>(`/api/admin/results${status ? `?status=${status}` : ""}`, [status]);
  async function verify(id: string) { try { const r = await api<any>("/api/admin/results", { method: "PATCH", body: JSON.stringify({ id, action: "verify" }) }); fx.toast(r.xpAwarded ? `Verified — +${r.xpAwarded} XP awarded.` : "Verified.", "ok"); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  async function reject(id: string) { try { await api("/api/admin/results", { method: "PATCH", body: JSON.stringify({ id, action: "reject" }) }); fx.toast("Rejected.", "info"); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  const rows: any[] = data?.results || [];
  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <H>{big ? "Image Analyzer" : "Results Management"}</H>
      <Err m={err} />
      <div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>
        {[["", "All"], ["pending", "Pending"], ["verified", "Verified"], ["duplicate", "Duplicates"], ["rejected", "Rejected"]].map(([k, l]) => (
          <button key={k} className="btn btn-ghost" style={{ fontSize: ".64rem", background: status === k ? "linear-gradient(120deg,#ff2d55,#ff8a3d)" : undefined, color: status === k ? "#1a0207" : undefined, border: "none" }} onClick={() => setStatus(k)}>{l}</button>
        ))}
      </div>
      {loading ? <Spinner /> : rows.length === 0 ? <p style={{ color: "var(--muted)" }}>No results.</p> : (
        <div style={{ display: "grid", gridTemplateColumns: big ? "repeat(auto-fill,minmax(260px,1fr))" : "1fr", gap: 12 }}>
          {rows.map((r: any) => (
            <div key={r.result.id} className="glass" style={{ padding: 12, display: "flex", gap: 12 }}>
              {r.result.imageDataUrl ? (
                <img src={r.result.imageDataUrl} alt="" style={{ width: big ? "100%" : 80, height: big ? 140 : 80, objectFit: "cover", borderRadius: 8, flexShrink: 0 }} />
              ) : <div style={{ width: 80, height: 80, borderRadius: 8, background: "#0a0e22" }} />}
              <div style={{ flex: 1, minWidth: 0, fontSize: ".8rem" }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
                  <b>@{r.username}</b>
                  <RankBadgeMini status={r.result.status} />
                </div>
                <div style={{ color: "var(--muted)", marginTop: 4 }}>{r.result.subject || "—"} · {r.result.marksObtained != null ? `${r.result.marksObtained}/${r.result.maxMarks ?? "?"}` : "no marks"} · conf {r.result.confidence ?? "—"}%</div>
                <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
                  {r.result.status !== "verified" && r.result.status !== "duplicate" && <button className="btn btn-primary" style={{ fontSize: ".6rem" }} onClick={() => verify(r.result.id)}>Verify</button>}
                  {r.result.status !== "rejected" && <button className="btn btn-danger" style={{ fontSize: ".6rem" }} onClick={() => reject(r.result.id)}>Reject</button>}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function RankBadgeMini({ status }: { status: string }) {
  const c = status === "verified" ? "var(--ok)" : status === "duplicate" ? "var(--danger)" : status === "rejected" ? "var(--danger)" : "var(--warn)";
  return <span className="rank-badge" style={{ "--rk-color": c, "--rk-glow": c, fontSize: ".6rem" } as React.CSSProperties}>{status}</span>;
}

/* ---------------- XP Control ---------------- */
function XpSection({ fx }: { fx: FX }) {
  const { data } = useFetch<any>("/api/admin/users");
  const users: any[] = data?.users || [];
  const [sel, setSel] = useState("");
  const { data: detail, reload } = useFetch<any>(sel ? `/api/admin/users/${sel}` : null, [sel]);
  async function act(action: string, value?: any, ok?: string) {
    try { await api("/api/admin/users", { method: "PATCH", body: JSON.stringify({ id: sel, action, value }) }); fx.toast(ok || "Updated.", "ok"); reload(); } catch (e: any) { fx.toast(e.message, "bad"); }
  }
  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <H>XP Control</H>
      <select className="field" style={{ width: "auto", marginBottom: 14 }} value={sel} onChange={(e) => setSel(e.target.value)}>
        <option value="">Select user…</option>
        {users.map((u) => <option key={u.id} value={u.id}>{u.username} · Lvl {u.level} · {u.xp.toLocaleString()} XP</option>)}
      </select>
      {!sel ? <p style={{ color: "var(--muted)" }}>Pick a user to modify XP. Every change is recorded in the audit log.</p> : (
        <>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => { const n = numPrompt("Add XP:"); if (n != null) act("addXp", n, "XP added."); }}>+ Add XP</button>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => { const n = numPrompt("Remove XP:"); if (n != null) act("removeXp", n, "XP removed."); }}>− Remove XP</button>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => { const n = numPrompt("Set exact XP:"); if (n != null) act("setXp", n, "XP set."); }}>Set Exact XP</button>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => { const n = numPrompt("Set exact level:"); if (n != null) act("setLevel", n, "Level set."); }}>Set Exact Level</button>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => act("resetXp", undefined, "XP reset.")}>Reset XP</button>
            <button className="btn" style={{ fontSize: ".64rem" }} onClick={() => act("resetLevel", undefined, "Level reset.")}>Reset Level</button>
          </div>
          {detail && (
            <div style={{ marginTop: 14 }}>
              <div className="label">XP History</div>
              <div style={{ maxHeight: 260, overflow: "auto", border: "1px solid var(--border)", borderRadius: 10 }}>
                {(detail.xpHistory || []).map((h: any) => (
                  <div key={h.id} style={{ display: "flex", justifyContent: "space-between", padding: "6px 10px", fontSize: ".78rem", borderBottom: "1px solid rgba(255,255,255,.05)" }}>
                    <span>{h.reason} <span style={{ color: "var(--muted)" }}>· {h.source}</span></span>
                    <span style={{ color: h.amount >= 0 ? "var(--ok)" : "var(--danger)" }}>{h.amount >= 0 ? "+" : ""}{h.amount} → {h.balanceAfter.toLocaleString()}</span>
                  </div>
                ))}
                {(!detail.xpHistory || detail.xpHistory.length === 0) && <div style={{ padding: 10, color: "var(--muted)" }}>No history.</div>}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* ---------------- Level Management ---------------- */
function LevelsSection({ fx }: { fx: FX }) {
  const { data } = useFetch<any>("/api/admin/settings");
  const [base, setBase] = useState("");
  useEffect(() => { if (data) setBase(data.settings.xp_per_level_base); }, [data]);
  async function save() { try { await api("/api/admin/settings", { method: "PATCH", body: JSON.stringify({ settings: { xp_per_level_base: String(base) } }) }); fx.toast("Level curve updated.", "ok"); } catch (e: any) { fx.toast(e.message, "bad"); } }
  const b = Number(base) || 100;
  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <H>Level Management</H>
      <p style={{ color: "var(--muted)", fontSize: ".84rem" }}>XP to advance from level <b>L</b> to <b>L+1</b> = <code>base × L</code>. Configure the base below.</p>
      <div style={{ display: "flex", gap: 8, alignItems: "end", flexWrap: "wrap" }}>
        <div><label className="label">Base XP per level</label><input className="field" style={{ width: 160 }} type="number" value={base} onChange={(e) => setBase(e.target.value)} /></div>
        <button className="btn btn-primary" onClick={save}>Save Curve</button>
      </div>
      <div style={{ marginTop: 16, display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(120px,1fr))", gap: 10 }}>
        {[1, 5, 10, 25, 50, 100, 200].map((L) => (
          <div key={L} className="glass" style={{ padding: "0.8rem", textAlign: "center" }}>
            <div style={{ color: "var(--muted)", fontSize: ".64rem", fontFamily: "Orbitron" }}>LEVEL {L}</div>
            <div style={{ fontFamily: "Orbitron", fontWeight: 700 }}>{xpAtLevel(L, b).toLocaleString()} XP</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Role Management ---------------- */
function RolesSection({ fx }: { fx: FX }) {
  const { data, reload } = useFetch<any>("/api/admin/roles");
  const roles: any[] = data?.roles || [];
  async function save(r: any, patch: any) { try { await api("/api/admin/roles", { method: "PATCH", body: JSON.stringify({ id: r.id, ...patch }) }); fx.toast("Role updated.", "ok"); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  async function del(r: any) { if (!confirm(`Delete custom role ${r.name}?`)) return; try { await api("/api/admin/roles", { method: "DELETE", body: JSON.stringify({ id: r.id }) }); fx.toast("Role deleted.", "ok"); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  const [nName, setNName] = useState(""); const [nColor, setNColor] = useState("#7c5cff"); const [nLvl, setNLvl] = useState(1);
  async function create() { try { await api("/api/admin/roles", { method: "POST", body: JSON.stringify({ name: nName, color: nColor, glow: nColor, levelRequirement: nLvl, autoUnlock: false }) }); fx.toast("Role created.", "ok"); setNName(""); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <H>Role / Rank Management</H>
      <div style={{ display: "grid", gap: 12 }}>
        {roles.map((r) => <RoleRow key={r.id} role={r} onSave={(p) => save(r, p)} onDelete={() => del(r)} />)}
      </div>
      <div style={{ marginTop: 18, paddingTop: 16, borderTop: "1px solid var(--border)" }}>
        <div className="label">Create Custom Role</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "end" }}>
          <div><label className="label">Name</label><input className="field" style={{ width: 150 }} value={nName} onChange={(e) => setNName(e.target.value)} /></div>
          <div><label className="label">Color</label><input type="color" value={nColor} onChange={(e) => setNColor(e.target.value)} style={{ width: 48, height: 38, background: "transparent", border: "1px solid var(--border)", borderRadius: 8 }} /></div>
          <div><label className="label">Level req</label><input className="field" style={{ width: 90 }} type="number" value={nLvl} onChange={(e) => setNLvl(Number(e.target.value))} /></div>
          <button className="btn btn-primary" onClick={create}>Create</button>
        </div>
      </div>
    </div>
  );
}

function RoleRow({ role, onSave, onDelete }: { role: any; onSave: (p: any) => void; onDelete: () => void }) {
  const [c, setC] = useState(role.color); const [g, setG] = useState(role.glow); const [lvl, setLvl] = useState(role.levelRequirement); const [giftable, setGiftable] = useState(role.giftable); const [auto, setAuto] = useState(role.autoUnlock);
  return (
    <div className="glass" style={{ padding: 12, display: "grid", gap: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
        <RankOrb role={{ ...role, color: c, glow: g }} size={52} />
        <b style={{ fontFamily: "Orbitron", letterSpacing: ".08em" }}>{role.name}</b>
        {role.custom && <span className="rank-badge" style={{ "--rk-color": "var(--neon-2)", "--rk-glow": "var(--neon-2)" } as React.CSSProperties}>CUSTOM</span>}
      </div>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "end" }}>
        <div><label className="label">Color</label><input type="color" value={c} onChange={(e) => setC(e.target.value)} style={{ width: 44, height: 36, background: "transparent", border: "1px solid var(--border)", borderRadius: 8 }} /></div>
        <div><label className="label">Glow</label><input type="color" value={g} onChange={(e) => setG(e.target.value)} style={{ width: 44, height: 36, background: "transparent", border: "1px solid var(--border)", borderRadius: 8 }} /></div>
        <div><label className="label">Badge</label><input className="field" style={{ width: 70 }} value={role.badge} readOnly /></div>
        <div><label className="label">Level req</label><input className="field" style={{ width: 90 }} type="number" value={lvl} onChange={(e) => setLvl(Number(e.target.value))} /></div>
        <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: ".78rem" }}><input type="checkbox" checked={giftable} onChange={(e) => setGiftable(e.target.checked)} /> Giftable</label>
        <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: ".78rem" }}><input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} /> Auto-unlock</label>
        <button className="btn btn-primary" style={{ fontSize: ".64rem" }} onClick={() => onSave({ color: c, glow: g, levelRequirement: lvl, giftable, autoUnlock: auto })}>Save</button>
        {role.custom && <button className="btn btn-danger" style={{ fontSize: ".64rem" }} onClick={onDelete}>Delete</button>}
      </div>
    </div>
  );
}

/* ---------------- Gift Management ---------------- */
function GiftsSection({ fx }: { fx: FX }) {
  const { data } = useFetch<any>("/api/admin/users");
  const users: any[] = data?.users || []; const roles: any[] = data?.roles || [];
  const [uSel, setUSel] = useState(""); const [rSel, setRSel] = useState("");
  const { data: sent, reload } = useFetch<any>("/api/admin/gifts");
  async function send() { if (!uSel || !rSel) return; try { await api("/api/admin/gifts", { method: "POST", body: JSON.stringify({ userId: uSel, roleId: rSel }) }); fx.toast("Gift sent to Gift Box.", "ok"); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <H>Gift Management</H>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "end", marginBottom: 16 }}>
        <div><label className="label">User</label><select className="field" style={{ width: 180 }} value={uSel} onChange={(e) => setUSel(e.target.value)}><option value="">Select…</option>{users.filter((u) => !u.isAdmin).map((u) => <option key={u.id} value={u.id}>{u.username}</option>)}</select></div>
        <div><label className="label">Role</label><select className="field" style={{ width: 180 }} value={rSel} onChange={(e) => setRSel(e.target.value)}><option value="">Select…</option>{roles.filter((r: any) => r.giftable).map((r: any) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>
        <button className="btn btn-gold" onClick={send}>🎁 Send Gift</button>
      </div>
      <div className="label">Sent Gifts</div>
      <div style={{ maxHeight: 320, overflow: "auto", border: "1px solid var(--border)", borderRadius: 10 }}>
        {(sent?.gifts || []).map((g: any) => (
          <div key={g.id} style={{ display: "flex", justifyContent: "space-between", padding: "8px 12px", fontSize: ".8rem", borderBottom: "1px solid rgba(255,255,255,.05)" }}>
            <span>{g.roleName} → user {g.userId.slice(0, 8)}</span>
            <span style={{ color: g.claimed ? "var(--ok)" : "var(--warn)" }}>{g.claimed ? "Claimed" : "Unclaimed"}</span>
          </div>
        ))}
        {(!sent?.gifts || sent.gifts.length === 0) && <div style={{ padding: 10, color: "var(--muted)" }}>No gifts sent.</div>}
      </div>
    </div>
  );
}

/* ---------------- XP Codes ---------------- */
function CodesSection({ fx }: { fx: FX }) {
  const { data, reload } = useFetch<any>("/api/admin/codes");
  const codes: any[] = data?.codes || [];
  const [form, setForm] = useState({ code: "", xpReward: 100, unlimitedXp: false, maxUses: "", onePerUser: true, active: true });
  async function create() { try { await api("/api/admin/codes", { method: "POST", body: JSON.stringify({ ...form, maxUses: form.maxUses === "" ? null : Number(form.maxUses) }) }); fx.toast("Code created.", "ok"); setForm({ code: "", xpReward: 100, unlimitedXp: false, maxUses: "", onePerUser: true, active: true }); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  async function toggle(c: any) { try { await api(`/api/admin/codes/${c.id}`, { method: "PATCH", body: JSON.stringify({ active: !c.active }) }); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  async function del(c: any) { if (!confirm(`Delete code ${c.code}?`)) return; try { await api(`/api/admin/codes/${c.id}`, { method: "DELETE", body: JSON.stringify({}) }); fx.toast("Code deleted.", "ok"); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <H>XP Code Management</H>
      <div className="glass" style={{ padding: 12, marginBottom: 16 }}>
        <div className="label">Create Code</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "end" }}>
          <div><label className="label">Code</label><input className="field" style={{ width: 150 }} value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} /></div>
          <div><label className="label">XP</label><input className="field" style={{ width: 90 }} type="number" value={form.xpReward} onChange={(e) => setForm({ ...form, xpReward: Number(e.target.value) })} /></div>
          <div><label className="label">Max uses</label><input className="field" style={{ width: 90 }} value={form.maxUses} onChange={(e) => setForm({ ...form, maxUses: e.target.value })} placeholder="∞" /></div>
          <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: ".78rem" }}><input type="checkbox" checked={form.unlimitedXp} onChange={(e) => setForm({ ...form, unlimitedXp: e.target.checked })} /> Unlimited</label>
          <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: ".78rem" }}><input type="checkbox" checked={form.onePerUser} onChange={(e) => setForm({ ...form, onePerUser: e.target.checked })} /> 1/user</label>
          <button className="btn btn-primary" onClick={create}>Create</button>
        </div>
      </div>
      <div style={{ overflowX: "auto" }}>
        <table className="tbl">
          <thead><tr><th>Code</th><th>Reward</th><th>Uses</th><th>Status</th><th>Unlimited</th><th>1/user</th><th>Created</th><th></th></tr></thead>
          <tbody>
            {codes.map((c) => (
              <tr key={c.id}>
                <td style={{ fontFamily: "Orbitron" }}>{c.code}</td>
                <td>{c.unlimitedXp ? "∞ XP" : `${c.xpReward} XP`}</td>
                <td>{c.currentUses}{c.maxUses ? `/${c.maxUses}` : ""}</td>
                <td>{c.active ? <span style={{ color: "var(--ok)" }}>Active</span> : <span style={{ color: "var(--danger)" }}>Inactive</span>}</td>
                <td>{c.unlimitedXp ? "✓" : "—"}</td>
                <td>{c.onePerUser ? "✓" : "—"}</td>
                <td style={{ color: "var(--muted)", fontSize: ".74rem" }}>{new Date(c.createdAt).toLocaleDateString()}</td>
                <td><div style={{ display: "flex", gap: 4 }}><button className="btn" style={{ fontSize: ".6rem" }} onClick={() => toggle(c)}>{c.active ? "Disable" : "Enable"}</button><button className="btn btn-danger" style={{ fontSize: ".6rem" }} onClick={() => del(c)}>Delete</button></div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------------- Scoreboard ---------------- */
function ScoreboardSection() {
  const [metric, setMetric] = useState("xp");
  const { data, loading } = useFetch<any>(`/api/scoreboard?metric=${metric}`, [metric]);
  const board: any[] = data?.board || [];
  const valOf = (i: any) => metric === "xp" ? `${i.xp.toLocaleString()} XP` : metric === "level" ? `Lvl ${i.level}` : metric === "verified" ? `${i.verified} verified` : `${i.avgPct}%`;
  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <H>Scoreboard Management</H>
      <div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>
        {[["xp", "XP"], ["level", "Level"], ["verified", "Verified"], ["average", "Avg %"]].map(([k, l]) => (
          <button key={k} className="btn btn-ghost" style={{ fontSize: ".64rem", background: metric === k ? "linear-gradient(120deg,#ff2d55,#ff8a3d)" : undefined, color: metric === k ? "#1a0207" : undefined, border: "none" }} onClick={() => setMetric(k)}>{l}</button>
        ))}
      </div>
      {loading ? <Spinner /> : (
        <table className="tbl">
          <thead><tr><th>#</th><th>Pilot</th><th>Rank</th><th>Level</th><th>Value</th></tr></thead>
          <tbody>{board.map((p, i) => (<tr key={p.id}><td>{i + 1}</td><td>{p.username}</td><td><RankBadge role={p.role} /></td><td>{p.level}</td><td style={{ color: "var(--neon-2)" }}>{valOf(p)}</td></tr>))}</tbody>
        </table>
      )}
    </div>
  );
}

/* ---------------- Audit ---------------- */
function AuditSection() {
  const { data, loading } = useFetch<any>("/api/admin/audit?limit=200");
  const logs: any[] = data?.logs || [];
  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <H>Audit Logs</H>
      {loading ? <Spinner /> : (
        <div style={{ maxHeight: 540, overflow: "auto" }}>
          {logs.map((l) => (
            <div key={l.id} style={{ display: "flex", gap: 12, padding: "8px 6px", borderBottom: "1px solid rgba(255,255,255,.06)", fontSize: ".82rem" }}>
              <span style={{ color: "var(--neon)", fontFamily: "Orbitron", fontSize: ".64rem", minWidth: 110 }}>{l.action}</span>
              <span style={{ flex: 1 }}>{l.details}</span>
              <span style={{ color: "var(--muted)", fontSize: ".72rem" }}>{l.adminName} · {new Date(l.createdAt).toLocaleString()}</span>
            </div>
          ))}
          {logs.length === 0 && <p style={{ color: "var(--muted)" }}>No audit entries.</p>}
        </div>
      )}
    </div>
  );
}

/* ---------------- Settings ---------------- */
function SettingsSection({ fx }: { fx: FX }) {
  const { data, reload } = useFetch<any>("/api/admin/settings");
  const [s, setS] = useState<Record<string, string>>({});
  useEffect(() => { if (data) setS(data.settings); }, [data]);
  const fields = [["xp_per_verified_result", "XP per verified result"], ["xp_per_image_verified", "Image-verification bonus XP"], ["xp_per_level_base", "Base XP per level"], ["duplicate_threshold", "Duplicate hamming threshold"], ["possible_duplicate_threshold", "Possible-duplicate threshold"], ["analyzer_confidence_min", "Min confidence to auto-verify (%)"]];
  async function save() { try { await api("/api/admin/settings", { method: "PATCH", body: JSON.stringify({ settings: s }) }); fx.toast("Settings saved.", "ok"); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <H>Platform Settings</H>
      <div style={{ display: "grid", gap: 12, maxWidth: 520 }}>
        {fields.map(([k, l]) => (
          <div key={k}><label className="label">{l}</label><input className="field" type="number" value={s[k] ?? ""} onChange={(e) => setS({ ...s, [k]: e.target.value })} /></div>
        ))}
        <button className="btn btn-primary" onClick={save} style={{ width: "fit-content" }}>Save Settings</button>
      </div>
    </div>
  );
}

/* ---------------- Portfolio ---------------- */
function PortfolioSection({ fx }: { fx: FX }) {
  const { data, reload } = useFetch<any>("/api/admin/portfolio");
  const projects: any[] = data?.projects || [];
  const [edit, setEdit] = useState<any | null>(null);
  async function del(p: any) { if (!confirm(`Delete ${p.name}?`)) return; try { await api(`/api/admin/portfolio/${p.id}`, { method: "DELETE", body: JSON.stringify({}) }); fx.toast("Project deleted.", "ok"); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  async function move(p: any, dir: number) { try { await api(`/api/admin/portfolio/${p.id}`, { method: "PATCH", body: JSON.stringify({ sortOrder: (p.sortOrder || 0) + dir }) }); reload(); } catch (e: any) { fx.toast(e.message, "bad"); } }
  return (
    <div className="glass hud" style={{ padding: "1.3rem" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <H>Portfolio Management</H>
        <button className="btn btn-primary" style={{ margin: 0 }} onClick={() => setEdit({ name: "", description: "", category: "Web", imageUrl: "", technologies: [], features: [], screenshots: [], liveDemoUrl: "", sourceCodeUrl: "", featured: false, _new: true })}>+ Add Project</button>
      </div>
      <div style={{ display: "grid", gap: 10 }}>
        {projects.map((p) => (
          <div key={p.id} className="glass" style={{ padding: 12, display: "flex", gap: 12, alignItems: "center" }}>
            <img src={p.imageUrl} alt="" style={{ width: 70, height: 50, objectFit: "cover", borderRadius: 8 }} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <b>{p.name}</b> {p.featured && <span style={{ color: "var(--gold)", fontSize: ".7rem" }}>★ Featured</span>}
              <div style={{ color: "var(--muted)", fontSize: ".76rem" }}>{p.category} · order {p.sortOrder}</div>
            </div>
            <div style={{ display: "flex", gap: 4 }}>
              <button className="btn" style={{ fontSize: ".6rem" }} onClick={() => move(p, -1)}>▲</button>
              <button className="btn" style={{ fontSize: ".6rem" }} onClick={() => move(p, 1)}>▼</button>
              <button className="btn" style={{ fontSize: ".6rem" }} onClick={() => setEdit({ ...p, _tech: (p.technologies || []).join(", "), _feat: (p.features || []).join("\n"), _shots: (p.screenshots || []).join("\n") })}>Edit</button>
              <button className="btn btn-danger" style={{ fontSize: ".6rem" }} onClick={() => del(p)}>Delete</button>
            </div>
          </div>
        ))}
        {projects.length === 0 && <p style={{ color: "var(--muted)" }}>No projects.</p>}
      </div>
      {edit && <ProjectEditor fx={fx} project={edit} onClose={() => setEdit(null)} onChanged={reload} />}
    </div>
  );
}

function ProjectEditor({ fx, project, onClose, onChanged }: { fx: FX; project: any; onClose: () => void; onChanged: () => void }) {
  const [f, setF] = useState<any>(project);
  useEffect(() => { setF(project); }, [project]);
  async function save() {
    const payload = {
      name: f.name, description: f.description, category: f.category, imageUrl: f.imageUrl,
      technologies: (f._tech || "").split(",").map((x: string) => x.trim()).filter(Boolean),
      features: (f._feat || "").split("\n").map((x: string) => x.trim()).filter(Boolean),
      screenshots: (f._shots || "").split("\n").map((x: string) => x.trim()).filter(Boolean),
      liveDemoUrl: f.liveDemoUrl, sourceCodeUrl: f.sourceCodeUrl, featured: !!f.featured,
    };
    try {
      if (f._new) await api("/api/admin/portfolio", { method: "POST", body: JSON.stringify(payload) });
      else await api(`/api/admin/portfolio/${f.id}`, { method: "PATCH", body: JSON.stringify(payload) });
      fx.toast("Project saved.", "ok"); onChanged(); onClose();
    } catch (e: any) { fx.toast(e.message, "bad"); }
  }
  const set = (k: string, v: any) => setF({ ...f, [k]: v });
  return (
    <Modal title={f._new ? "Add Project" : `Edit ${f.name}`} onClose={onClose} width={620}>
      <div style={{ display: "grid", gap: 10 }}>
        <div><label className="label">Name</label><input className="field" value={f.name || ""} onChange={(e) => set("name", e.target.value)} /></div>
        <div><label className="label">Description</label><textarea className="field" rows={2} value={f.description || ""} onChange={(e) => set("description", e.target.value)} /></div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <div><label className="label">Category</label><input className="field" value={f.category || ""} onChange={(e) => set("category", e.target.value)} /></div>
          <div><label className="label">Preview image URL</label><input className="field" value={f.imageUrl || ""} onChange={(e) => set("imageUrl", e.target.value)} /></div>
        </div>
        <div><label className="label">Technologies (comma separated)</label><input className="field" value={f._tech || ""} onChange={(e) => set("_tech", e.target.value)} /></div>
        <div><label className="label">Features (one per line)</label><textarea className="field" rows={3} value={f._feat || ""} onChange={(e) => set("_feat", e.target.value)} /></div>
        <div><label className="label">Screenshot URLs (one per line)</label><textarea className="field" rows={3} value={f._shots || ""} onChange={(e) => set("_shots", e.target.value)} /></div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <div><label className="label">Live demo URL</label><input className="field" value={f.liveDemoUrl || ""} onChange={(e) => set("liveDemoUrl", e.target.value)} /></div>
          <div><label className="label">Source code URL</label><input className="field" value={f.sourceCodeUrl || ""} onChange={(e) => set("sourceCodeUrl", e.target.value)} /></div>
        </div>
        <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: ".84rem" }}><input type="checkbox" checked={!!f.featured} onChange={(e) => set("featured", e.target.checked)} /> Featured project</label>
        <button className="btn btn-primary" onClick={save}>Save Project</button>
      </div>
    </Modal>
  );
}
