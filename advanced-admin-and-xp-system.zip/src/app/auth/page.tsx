"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "@/lib/client";
import { useFx } from "@/components/fx";
import { Spinner } from "@/components/ui";

export default function AuthPage() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();
  const { toast } = useFx();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setErr("");
    try {
      await api("/api/auth", {
        method: "POST",
        body: JSON.stringify({ action: mode, username, password }),
      });
      toast(
        mode === "register" ? "Account created — welcome aboard!" : "Welcome back, commander.",
        "ok"
      );
      router.push("/dashboard");
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main
      className="page-in"
      style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: "2rem 1rem" }}
    >
      <div className="glass-solid hud neon-edge" style={{ width: 420, maxWidth: "94vw", padding: "2rem" }}>
        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <div className="rank-orb fx-glow" style={{ margin: "0 auto", width: 64, height: 64, fontSize: "1.5rem", "--rk-color": "#22d3ee", "--rk-glow": "#4f7bff" } as React.CSSProperties}>A</div>
          <h1 style={{ fontFamily: "Orbitron", letterSpacing: ".16em", margin: "12px 0 4px", fontSize: "1.3rem" }}>
            {mode === "login" ? "ACCESS TERMINAL" : "REGISTER CALLSIGN"}
          </h1>
          <p style={{ color: "var(--muted)", fontSize: ".82rem" }}>
            {mode === "login" ? "Authenticate to enter the command center." : "Create your pilot record."}
          </p>
        </div>

        <div style={{ display: "flex", gap: 8, marginBottom: 18, background: "rgba(0,0,0,.3)", padding: 4, borderRadius: 12 }}>
          {(["login", "register"] as const).map((m) => (
            <button
              key={m}
              onClick={() => { setMode(m); setErr(""); }}
              className="btn"
              style={{
                flex: 1,
                background: mode === m ? "linear-gradient(120deg,#2b4bff,#22d3ee)" : "transparent",
                color: mode === m ? "#02040c" : undefined,
                border: "none",
              }}
            >
              {m === "login" ? "Login" : "Register"}
            </button>
          ))}
        </div>

        <form onSubmit={submit} style={{ display: "grid", gap: 14 }}>
          <div>
            <label className="label">Username</label>
            <input className="field" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="e.g. starpilot" autoComplete="username" />
          </div>
          <div>
            <label className="label">Password</label>
            <input className="field" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" autoComplete="current-password" />
          </div>
          {err && <div style={{ color: "var(--danger)", fontSize: ".82rem" }}>{err}</div>}
          <button className="btn btn-primary" disabled={loading} style={{ padding: "0.8rem" }}>
            {loading ? <Spinner /> : mode === "login" ? "▶ Authenticate" : "⚡ Create Account"}
          </button>
        </form>

        <div style={{ textAlign: "center", marginTop: 16 }}>
          <p style={{ color: "var(--muted)", fontSize: ".76rem" }}>
            Demo student: <b style={{ color: "var(--text)" }}>student1</b> / <b style={{ color: "var(--text)" }}>student123</b>
          </p>
          <div style={{ marginTop: 12, display: "flex", gap: 8, justifyContent: "center" }}>
            <Link className="btn btn-ghost" href="/scoreboard" style={{ fontSize: ".7rem" }}>Scoreboard</Link>
            <Link className="btn btn-ghost" href="/portfolio" style={{ fontSize: ".7rem" }}>Portfolio</Link>
            <Link className="btn btn-ghost" href="/admin/login" style={{ fontSize: ".7rem" }}>Admin</Link>
          </div>
        </div>
      </div>
    </main>
  );
}
