import { NextResponse } from "next/server";
import { eq, sql, count } from "drizzle-orm";
import { db } from "@/db";
import { users, results } from "@/db/schema";
import { getRoles } from "@/lib/public";
import { resolveRank, effectForRole } from "@/lib/ranks";
import { levelProgress } from "@/lib/xp";
import { getAllSettings, num } from "@/lib/settings";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeed().catch(() => {});
  const metric = new URL(req.url).searchParams.get("metric") || "xp";
  const settings = await getAllSettings();
  const base = num(settings.xp_per_level_base, 100);

  const us = await db
    .select()
    .from(users)
    .where(eq(users.isAdmin, false));
  const agg = await db
    .select({
      userId: results.userId,
      tests: count(),
      verified: sql<number>`count(*) filter (where ${results.status} = 'verified')`,
      avgPct: sql<number>`coalesce(avg(${results.percentage}) filter (where ${results.status} = 'verified'), 0)`,
    })
    .from(results)
    .groupBy(results.userId);
  const map = new Map(agg.map((a) => [a.userId, a]));
  const roles = await getRoles();

  const items = us.map((u) => {
    const a = map.get(u.id) ?? { tests: 0, verified: 0, avgPct: 0 };
    const role = resolveRank(u.level, u.manualRoleId, u.giftRoleId, roles);
    return {
      id: u.id,
      username: u.username,
      avatarSeed: u.avatarSeed,
      xp: u.xp,
      level: u.level,
      tests: Number(a.tests) || 0,
      verified: Number(a.verified) || 0,
      avgPct: Math.round(Number(a.avgPct) || 0),
      role: { ...role, effect: effectForRole(role) },
      progress: levelProgress(u.xp, base),
    };
  });

  const key =
    metric === "level"
      ? (i: (typeof items)[number]) => i.level
      : metric === "verified"
      ? (i: (typeof items)[number]) => i.verified
      : metric === "average"
      ? (i: (typeof items)[number]) => i.avgPct
      : (i: (typeof items)[number]) => i.xp;
  items.sort((a, b) => key(b) - key(a));

  return NextResponse.json({ board: items, metric });
}
