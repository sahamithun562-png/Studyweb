import { NextResponse } from "next/server";
import { eq, sql, and } from "drizzle-orm";
import { db } from "@/db";
import { xpCodes, xpCodeRedemptions } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { applyXp } from "@/lib/progress";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const u = await requireUser();
  if (!u) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const code = String(body.code || "").trim();
  if (!code)
    return NextResponse.json({ error: "Enter an XP code." }, { status: 400 });

  const rows = await db
    .select()
    .from(xpCodes)
    .where(eq(xpCodes.code, code))
    .limit(1);
  const c = rows[0];
  if (!c)
    return NextResponse.json({ error: "Invalid XP code." }, { status: 404 });
  if (!c.active)
    return NextResponse.json({ error: "This code is inactive." }, { status: 400 });
  if (c.expiresAt && c.expiresAt.getTime() < Date.now())
    return NextResponse.json({ error: "This code has expired." }, { status: 400 });
  if (c.maxUses != null && c.currentUses >= c.maxUses)
    return NextResponse.json(
      { error: "This code has reached its usage limit." },
      { status: 400 }
    );

  if (c.onePerUser) {
    const existing = await db
      .select({ id: xpCodeRedemptions.id })
      .from(xpCodeRedemptions)
      .where(
        and(
          eq(xpCodeRedemptions.userId, u.id),
          eq(xpCodeRedemptions.codeId, c.id)
        )
      )
      .limit(1);
    if (existing.length)
      return NextResponse.json(
        { error: "This code has already been redeemed by your account." },
        { status: 409 }
      );
  }

  try {
    await db
      .insert(xpCodeRedemptions)
      .values({ userId: u.id, codeId: c.id });
  } catch {
    return NextResponse.json(
      { error: "This code has already been redeemed by your account." },
      { status: 409 }
    );
  }

  await db
    .update(xpCodes)
    .set({ currentUses: sql`${xpCodes.currentUses} + 1` })
    .where(eq(xpCodes.id, c.id));

  const award = c.unlimitedXp ? 1_000_000 : c.xpReward;
  await applyXp(u.id, award, `Redeemed code ${c.code}`, "code");

  return NextResponse.json({
    ok: true,
    awarded: award,
    unlimited: !!c.unlimitedXp,
    message: c.unlimitedXp
      ? "UNLIMITED XP MODE ACTIVATED!"
      : "XP CODE ACTIVATED!",
  });
}
