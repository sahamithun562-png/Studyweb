import { NextResponse } from "next/server";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeed();
  } catch {
    /* seed is best-effort on health; surface ok regardless */
  }
  return NextResponse.json({ status: "ok" });
}
