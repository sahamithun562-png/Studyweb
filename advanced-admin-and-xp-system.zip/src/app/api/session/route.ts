import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { profileOf } from "@/lib/public";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed().catch(() => {});
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ user: null });
  return NextResponse.json({ user: await profileOf(u) });
}
