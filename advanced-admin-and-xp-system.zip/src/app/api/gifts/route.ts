import { NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { gifts, users } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { profileOf } from "@/lib/public";

export const dynamic = "force-dynamic";

export async function GET() {
  const u = await requireUser();
  if (!u) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await db
    .select()
    .from(gifts)
    .where(eq(gifts.userId, u.id))
    .orderBy(desc(gifts.createdAt));
  const unread = rows.filter((g) => !g.claimed).length;
  return NextResponse.json({ gifts: rows, unread });
}

export async function PATCH(req: Request) {
  const u = await requireUser();
  if (!u) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { giftId } = await req.json().catch(() => ({}));
  const rows = await db
    .select()
    .from(gifts)
    .where(eq(gifts.id, String(giftId)))
    .limit(1);
  const g = rows[0];
  if (!g || g.userId !== u.id)
    return NextResponse.json({ error: "Not found." }, { status: 404 });
  if (g.roleId) {
    await db
      .update(users)
      .set({ giftRoleId: g.roleId })
      .where(eq(users.id, u.id));
  }
  await db.update(gifts).set({ claimed: true }).where(eq(gifts.id, g.id));
  const fresh = await profileOf(u);
  return NextResponse.json({ ok: true, user: fresh, gift: g });
}
