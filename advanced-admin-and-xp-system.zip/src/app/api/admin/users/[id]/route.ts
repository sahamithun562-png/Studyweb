import { NextResponse } from "next/server";
import { eq, desc, asc } from "drizzle-orm";
import { db } from "@/db";
import { users, results, xpHistory, gifts, roles } from "@/db/schema";
import { requireAdminUser } from "@/lib/auth";
import { profileOf } from "@/lib/public";

export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  const u = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!u.length) return NextResponse.json({ error: "Not found." }, { status: 404 });

  const profile = await profileOf(u[0]);
  const res = await db
    .select()
    .from(results)
    .where(eq(results.userId, id))
    .orderBy(desc(results.createdAt));
  const hist = await db
    .select()
    .from(xpHistory)
    .where(eq(xpHistory.userId, id))
    .orderBy(desc(xpHistory.createdAt))
    .limit(60);
  const gfts = await db
    .select()
    .from(gifts)
    .where(eq(gifts.userId, id))
    .orderBy(desc(gifts.createdAt));
  const allRoles = await db.select().from(roles).orderBy(asc(roles.sortOrder));

  return NextResponse.json({
    profile,
    results: res,
    xpHistory: hist,
    gifts: gfts,
    roles: allRoles,
    selfId: admin.id,
  });
}
