import { NextResponse } from "next/server";
import { eq, desc, sql, count, asc } from "drizzle-orm";
import { db } from "@/db";
import { users, results, roles } from "@/db/schema";
import { requireAdminUser, writeAudit } from "@/lib/auth";
import { resolveRank, effectForRole } from "@/lib/ranks";
import { levelProgress } from "@/lib/xp";
import { getAllSettings, num } from "@/lib/settings";
import {
  applyXp,
  setExactXp,
  setExactLevel,
  resetXp,
  resetLevel,
} from "@/lib/progress";
import { profileOf } from "@/lib/public";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const settings = await getAllSettings();
  const base = num(settings.xp_per_level_base, 100);

  const us = await db.select().from(users).orderBy(desc(users.createdAt));
  const agg = await db
    .select({
      userId: results.userId,
      tests: count(),
      verified: sql<number>`count(*) filter (where ${results.status} = 'verified')`,
    })
    .from(results)
    .groupBy(results.userId);
  const map = new Map(agg.map((a) => [a.userId, a]));
  const allRoles = await db.select().from(roles).orderBy(asc(roles.sortOrder));

  const list = us.map((u) => {
    const a = map.get(u.id) ?? { tests: 0, verified: 0 };
    const role = resolveRank(u.level, u.manualRoleId, u.giftRoleId, allRoles);
    return {
      id: u.id,
      username: u.username,
      avatarSeed: u.avatarSeed,
      xp: u.xp,
      level: u.level,
      status: u.status,
      isAdmin: u.isAdmin,
      isOwner: u.isOwner,
      testsCount: Number(a.tests) || 0,
      verifiedCount: Number(a.verified) || 0,
      createdAt: u.createdAt,
      lastActiveAt: u.lastActiveAt,
      role: { ...role, effect: effectForRole(role) },
      progress: levelProgress(u.xp, base),
    };
  });

  return NextResponse.json({ users: list, roles: allRoles, selfId: admin.id });
}

export async function PATCH(req: Request) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  const { id, action } = body;
  if (!id) return NextResponse.json({ error: "Missing id." }, { status: 400 });

  const targetRows = await db.select().from(users).where(eq(users.id, id)).limit(1);
  const target = targetRows[0];
  if (!target) return NextResponse.json({ error: "User not found." }, { status: 404 });

  const selfOrOwner = target.isOwner || target.id === admin.id;

  if (action === "block") {
    if (selfOrOwner)
      return NextResponse.json(
        { error: "You cannot block your own administrator account." },
        { status: 403 }
      );
    await db.update(users).set({ status: "blocked" }).where(eq(users.id, id));
    await writeAudit(admin, "BLOCK_USER", `Blocked @${target.username}`, id);
  } else if (action === "unblock") {
    await db.update(users).set({ status: "active" }).where(eq(users.id, id));
    await writeAudit(admin, "UNBLOCK_USER", `Unblocked @${target.username}`, id);
  } else if (action === "setLevel") {
    const res = await setExactLevel(id, Number(body.value), `Level set by ${admin.username}`);
    await writeAudit(
      admin,
      "SET_LEVEL",
      `Changed @${target.username} level ${res?.oldLevel} → ${res?.newLevel}`,
      id
    );
  } else if (action === "setXp") {
    const res = await setExactXp(id, Number(body.value), `XP set by ${admin.username}`);
    await writeAudit(
      admin,
      "SET_XP",
      `Changed @${target.username} XP ${res?.oldXp?.toLocaleString()} → ${res?.newXp?.toLocaleString()}`,
      id
    );
  } else if (action === "addXp") {
    const res = await applyXp(id, Number(body.value), `XP added by ${admin.username}`, "admin");
    await writeAudit(
      admin,
      "ADD_XP",
      `Added ${body.value} XP to @${target.username} (${res?.oldXp?.toLocaleString()} → ${res?.newXp?.toLocaleString()})`,
      id
    );
  } else if (action === "removeXp") {
    const res = await applyXp(id, -Number(body.value), `XP removed by ${admin.username}`, "admin");
    await writeAudit(
      admin,
      "REMOVE_XP",
      `Removed ${body.value} XP from @${target.username} (${res?.oldXp?.toLocaleString()} → ${res?.newXp?.toLocaleString()})`,
      id
    );
  } else if (action === "resetXp") {
    await resetXp(id);
    await writeAudit(admin, "RESET_XP", `Reset @${target.username} XP`, id);
  } else if (action === "resetLevel") {
    await resetLevel(id);
    await writeAudit(admin, "RESET_LEVEL", `Reset @${target.username} level`, id);
  } else if (action === "setRole") {
    await db.update(users).set({ manualRoleId: body.roleId || null }).where(eq(users.id, id));
    await writeAudit(admin, "SET_ROLE", `Set manual role for @${target.username}`, id);
  } else if (action === "clearRole") {
    await db.update(users).set({ manualRoleId: null }).where(eq(users.id, id));
    await writeAudit(admin, "CLEAR_ROLE", `Cleared manual role for @${target.username}`, id);
  } else if (action === "clearGiftRole") {
    await db.update(users).set({ giftRoleId: null }).where(eq(users.id, id));
    await writeAudit(admin, "CLEAR_GIFT", `Removed gifted role from @${target.username}`, id);
  } else {
    return NextResponse.json({ error: "Unknown action." }, { status: 400 });
  }

  const fresh = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return NextResponse.json({ user: fresh[0] ? await profileOf(fresh[0]) : null });
}
