import { NextResponse } from "next/server";
import { eq, asc, sql } from "drizzle-orm";
import { db } from "@/db";
import { roles } from "@/db/schema";
import { requireAdminUser, writeAudit } from "@/lib/auth";
import { invalidateRolesCache } from "@/lib/public";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const rows = await db.select().from(roles).orderBy(asc(roles.sortOrder));
  return NextResponse.json({ roles: rows });
}

export async function POST(req: Request) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const name = String(b.name || "Custom").trim().toUpperCase();
  const key = String(b.key || name.toLowerCase().replace(/[^a-z0-9]+/g, "-"));
  const maxRow = await db.select({ s: sql<number>`max(${roles.sortOrder})` }).from(roles);
  const sortOrder = (Number(maxRow[0]?.s) || 0) + 1;
  const [row] = await db
    .insert(roles)
    .values({
      key,
      name,
      color: b.color || "#7c5cff",
      glow: b.glow || b.color || "#a855f7",
      badge: b.badge || "✦",
      levelRequirement: Number(b.levelRequirement) || 1,
      xpRequirement: Number(b.xpRequirement) || 0,
      giftable: b.giftable !== false,
      autoUnlock: b.autoUnlock === true,
      custom: true,
      sortOrder,
    })
    .returning();
  invalidateRolesCache();
  await writeAudit(admin, "CREATE_ROLE", `Created role ${name}`);
  return NextResponse.json({ role: row });
}

export async function PATCH(req: Request) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const { id } = b;
  if (!id) return NextResponse.json({ error: "Missing id." }, { status: 400 });
  const patch: Record<string, unknown> = {};
  for (const k of [
    "name",
    "color",
    "glow",
    "badge",
    "levelRequirement",
    "xpRequirement",
    "giftable",
    "autoUnlock",
    "sortOrder",
  ]) {
    if (b[k] !== undefined) patch[k] = b[k];
  }
  await db.update(roles).set(patch).where(eq(roles.id, id));
  invalidateRolesCache();
  await writeAudit(admin, "UPDATE_ROLE", `Updated role configuration`);
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await req.json().catch(() => ({}));
  const rows = await db.select().from(roles).where(eq(roles.id, String(id))).limit(1);
  if (!rows[0]?.custom)
    return NextResponse.json({ error: "Built-in ranks cannot be deleted." }, { status: 400 });
  await db.delete(roles).where(eq(roles.id, String(id)));
  invalidateRolesCache();
  await writeAudit(admin, "DELETE_ROLE", `Deleted custom role ${rows[0].name}`);
  return NextResponse.json({ ok: true });
}
