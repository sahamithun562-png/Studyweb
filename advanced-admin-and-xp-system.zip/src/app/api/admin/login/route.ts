import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  verifyPassword,
  createSession,
  setSessionCookie,
  checkRateLimit,
  recordFailedLogin,
  clearFailedLogin,
} from "@/lib/auth";
import { profileOf } from "@/lib/public";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const username = String(body.username || "").trim();
  const password = String(body.password || "");
  const xf = req.headers.get("x-forwarded-for");
  const clientIp = (xf?.split(",")[0] || "local").trim();
  const key = `admin:${clientIp}:${username.toLowerCase()}`;

  const rl = checkRateLimit(key);
  if (!rl.ok)
    return NextResponse.json(
      { error: `Too many failed attempts. Locked for ${rl.retryAfter}s.` },
      { status: 429 }
    );

  const rows = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);
  const u = rows[0];
  const ok = u && (await verifyPassword(password, u.passwordHash));
  if (!ok || !u?.isAdmin) {
    recordFailedLogin(key);
    return NextResponse.json({ error: "Invalid administrator credentials." }, { status: 401 });
  }
  if (u.status === "blocked")
    return NextResponse.json({ error: "This administrator account is blocked." }, { status: 403 });

  const token = await createSession(u.id);
  await setSessionCookie(token);
  clearFailedLogin(key);
  return NextResponse.json({ user: await profileOf(u) });
}
