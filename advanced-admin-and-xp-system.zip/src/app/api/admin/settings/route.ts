import { NextResponse } from "next/server";
import { requireAdminUser, writeAudit } from "@/lib/auth";
import { getAllSettings, upsertSetting } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  return NextResponse.json({ settings: await getAllSettings() });
}

export async function PATCH(req: Request) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  const incoming = body.settings ?? body;
  for (const [k, v] of Object.entries(incoming)) {
    await upsertSetting(k, String(v));
  }
  await writeAudit(admin, "UPDATE_SETTINGS", "Updated platform settings");
  return NextResponse.json({ ok: true, settings: await getAllSettings() });
}
