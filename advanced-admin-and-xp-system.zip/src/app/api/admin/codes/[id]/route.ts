import { NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { xpCodes, xpCodeRedemptions, users } from "@/db/schema";
import { requireAdminUser, writeAudit } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  const codeRows = await db.select().from(xpCodes).where(eq(xpCodes.id, id)).limit(1);
  if (!codeRows.length) return NextResponse.json({ error: "Not found." }, { status: 404 });
  const redemptions = await db
    .select({ redemption: xpCodeRedemptions, username: users.username })
    .from(xpCodeRedemptions)
    .innerJoin(users, eq(users.id, xpCodeRedemptions.userId))
    .where(eq(xpCodeRedemptions.codeId, id))
    .orderBy(desc(xpCodeRedemptions.createdAt));
  return NextResponse.json({ code: codeRows[0], redemptions });
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  const b = await req.json().catch(() => ({}));
  const patch: Record<string, unknown> = {};
  for (const k of ["code", "xpReward", "unlimitedXp", "active", "maxUses", "onePerUser"]) {
    if (b[k] !== undefined) patch[k] = b[k];
  }
  if (b.expiresAt !== undefined)
    patch.expiresAt = b.expiresAt ? new Date(b.expiresAt) : null;
  if (patch.code) patch.code = String(patch.code).toUpperCase();
  if (patch.maxUses === "") patch.maxUses = null;
  await db.update(xpCodes).set(patch).where(eq(xpCodes.id, id));
  await writeAudit(admin, "UPDATE_CODE", `Updated XP code`);
  return NextResponse.json({ ok: true });
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  const rows = await db.select().from(xpCodes).where(eq(xpCodes.id, id)).limit(1);
  await db.delete(xpCodes).where(eq(xpCodes.id, id));
  await writeAudit(admin, "DELETE_CODE", `Deleted XP code ${rows[0]?.code ?? id}`);
  return NextResponse.json({ ok: true });
}
