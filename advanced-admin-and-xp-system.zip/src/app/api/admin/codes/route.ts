import { NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { xpCodes } from "@/db/schema";
import { requireAdminUser, writeAudit } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const rows = await db.select().from(xpCodes).orderBy(desc(xpCodes.createdAt));
  return NextResponse.json({ codes: rows });
}

export async function POST(req: Request) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const code = String(b.code || "").trim().toUpperCase();
  if (!code) return NextResponse.json({ error: "Code required." }, { status: 400 });
  const existing = await db.select({ id: xpCodes.id }).from(xpCodes).where(eq(xpCodes.code, code)).limit(1);
  if (existing.length) return NextResponse.json({ error: "Code already exists." }, { status: 409 });
  const [row] = await db
    .insert(xpCodes)
    .values({
      code,
      xpReward: Number(b.xpReward) || 0,
      unlimitedXp: b.unlimitedXp === true,
      active: b.active !== false,
      maxUses: b.maxUses != null && b.maxUses !== "" ? Number(b.maxUses) : null,
      onePerUser: b.onePerUser !== false,
      expiresAt: b.expiresAt ? new Date(b.expiresAt) : null,
      createdById: admin.id,
    })
    .returning();
  await writeAudit(admin, "CREATE_CODE", `Created XP code ${code}`);
  return NextResponse.json({ code: row });
}
