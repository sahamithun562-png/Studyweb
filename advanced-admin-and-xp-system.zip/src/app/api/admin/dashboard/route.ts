import { NextResponse } from "next/server";
import { eq, sql, desc, count } from "drizzle-orm";
import { db } from "@/db";
import { users, results, gifts, xpCodes, auditLogs } from "@/db/schema";
import { requireAdminUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const [u] = await db
    .select({
      total: count(),
      blocked: sql<number>`count(*) filter (where ${users.status} = 'blocked')`,
    })
    .from(users);
  const [r] = await db
    .select({
      total: count(),
      verified: sql<number>`count(*) filter (where ${results.status} = 'verified')`,
      pending: sql<number>`count(*) filter (where ${results.status} = 'pending')`,
      duplicate: sql<number>`count(*) filter (where ${results.status} = 'duplicate')`,
      rejected: sql<number>`count(*) filter (where ${results.status} = 'rejected')`,
    })
    .from(results);
  const [c] = await db
    .select({
      total: count(),
      active: sql<number>`count(*) filter (where ${xpCodes.active} = true)`,
    })
    .from(xpCodes);
  const [g] = await db
    .select({ unclaimed: count() })
    .from(gifts)
    .where(eq(gifts.claimed, false));
  const recent = await db
    .select()
    .from(auditLogs)
    .orderBy(desc(auditLogs.createdAt))
    .limit(8);

  return NextResponse.json({
    stats: {
      users: Number(u?.total) || 0,
      blocked: Number(u?.blocked) || 0,
      activeUsers: (Number(u?.total) || 0) - (Number(u?.blocked) || 0),
      results: Number(r?.total) || 0,
      verified: Number(r?.verified) || 0,
      pending: Number(r?.pending) || 0,
      duplicate: Number(r?.duplicate) || 0,
      rejected: Number(r?.rejected) || 0,
      codes: Number(c?.total) || 0,
      activeCodes: Number(c?.active) || 0,
      unclaimedGifts: Number(g?.unclaimed) || 0,
    },
    recent,
    admin: { username: admin.username, isOwner: admin.isOwner },
  });
}
