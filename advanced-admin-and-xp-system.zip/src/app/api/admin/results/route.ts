import { NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { results, users } from "@/db/schema";
import { requireAdminUser, writeAudit } from "@/lib/auth";
import { applyXp } from "@/lib/progress";
import { getAllSettings, num } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const status = new URL(req.url).searchParams.get("status");
  const base = db
    .select({ result: results, username: users.username })
    .from(results)
    .innerJoin(users, eq(users.id, results.userId));
  const rows = status
    ? await base
        .where(eq(results.status, status))
        .orderBy(desc(results.createdAt))
    : await base.orderBy(desc(results.createdAt));
  return NextResponse.json({ results: rows });
}

export async function PATCH(req: Request) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id, action } = await req.json().catch(() => ({}));
  const rows = await db.select().from(results).where(eq(results.id, String(id))).limit(1);
  const cur = rows[0];
  if (!cur) return NextResponse.json({ error: "Not found." }, { status: 404 });

  if (action === "verify") {
    if (cur.status === "verified")
      return NextResponse.json({ ok: true, already: true });
    if (cur.status === "duplicate")
      return NextResponse.json(
        { error: "Cannot verify a flagged duplicate." },
        { status: 400 }
      );
    await db.update(results).set({ status: "verified" }).where(eq(results.id, cur.id));
    const settings = await getAllSettings();
    const award =
      num(settings.xp_per_verified_result, 50) +
      num(settings.xp_per_image_verified, 3);
    await applyXp(cur.userId, award, "Result verified by admin", "result");
    await writeAudit(
      admin,
      "VERIFY_RESULT",
      `Verified result "${cur.subject || "test"}"`,
      cur.userId
    );
    return NextResponse.json({ ok: true, xpAwarded: award });
  }

  if (action === "reject") {
    await db.update(results).set({ status: "rejected" }).where(eq(results.id, cur.id));
    await writeAudit(
      admin,
      "REJECT_RESULT",
      `Rejected result "${cur.subject || "test"}"`,
      cur.userId
    );
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Unknown action." }, { status: 400 });
}
