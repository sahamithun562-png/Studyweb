import { NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { gifts, roles } from "@/db/schema";
import { requireAdminUser, writeAudit } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const rows = await db.select().from(gifts).orderBy(desc(gifts.createdAt));
  return NextResponse.json({ gifts: rows });
}

export async function POST(req: Request) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const { userId, roleId } = b;
  if (!userId || !roleId)
    return NextResponse.json({ error: "User and role required." }, { status: 400 });
  const roleRows = await db.select().from(roles).where(eq(roles.id, roleId)).limit(1);
  const role = roleRows[0];
  if (!role) return NextResponse.json({ error: "Role not found." }, { status: 404 });
  const [row] = await db
    .insert(gifts)
    .values({
      userId,
      type: "role",
      roleName: role.name,
      roleColor: role.color,
      roleBadge: role.badge,
      roleId: role.id,
      message: `You received the ${role.name} role.`,
    })
    .returning();
  await writeAudit(admin, "GIFT_ROLE", `Gifted ${role.name} role`, userId);
  return NextResponse.json({ gift: row });
}
