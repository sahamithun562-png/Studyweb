import { NextResponse } from "next/server";
import { asc, desc } from "drizzle-orm";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { requireAdminUser, writeAudit } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const rows = await db
    .select()
    .from(projects)
    .orderBy(desc(projects.featured), asc(projects.sortOrder), desc(projects.createdAt));
  return NextResponse.json({ projects: rows });
}

export async function POST(req: Request) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const [row] = await db
    .insert(projects)
    .values({
      name: String(b.name || "Untitled Project"),
      description: String(b.description || ""),
      features: Array.isArray(b.features) ? b.features : [],
      technologies: Array.isArray(b.technologies) ? b.technologies : [],
      category: String(b.category || "Web"),
      imageUrl: b.imageUrl || null,
      screenshots: Array.isArray(b.screenshots) ? b.screenshots : [],
      liveDemoUrl: b.liveDemoUrl || null,
      sourceCodeUrl: b.sourceCodeUrl || null,
      featured: b.featured === true,
      sortOrder: Number(b.sortOrder) || 0,
    })
    .returning();
  await writeAudit(admin, "CREATE_PROJECT", `Created project ${row.name}`);
  return NextResponse.json({ project: row });
}
