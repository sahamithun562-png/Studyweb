import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { requireAdminUser, writeAudit } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  const b = await req.json().catch(() => ({}));
  const patch: Record<string, unknown> = {};
  for (const k of [
    "name",
    "description",
    "category",
    "imageUrl",
    "liveDemoUrl",
    "sourceCodeUrl",
    "featured",
    "sortOrder",
  ]) {
    if (b[k] !== undefined) patch[k] = b[k];
  }
  if (Array.isArray(b.features)) patch.features = b.features;
  if (Array.isArray(b.technologies)) patch.technologies = b.technologies;
  if (Array.isArray(b.screenshots)) patch.screenshots = b.screenshots;
  await db.update(projects).set(patch).where(eq(projects.id, id));
  await writeAudit(admin, "UPDATE_PROJECT", `Updated project`);
  return NextResponse.json({ ok: true });
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await requireAdminUser();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  const rows = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  await db.delete(projects).where(eq(projects.id, id));
  await writeAudit(admin, "DELETE_PROJECT", `Deleted project ${rows[0]?.name ?? id}`);
  return NextResponse.json({ ok: true });
}
