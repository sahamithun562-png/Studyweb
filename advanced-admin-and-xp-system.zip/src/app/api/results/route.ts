import { NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { results } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { computeImageSignature } from "@/lib/image-hash";
import { detectDuplicate } from "@/lib/duplicate";
import { getAllSettings, num } from "@/lib/settings";
import { applyXp } from "@/lib/progress";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const ALLOWED = ["image/jpeg", "image/png", "image/webp", "image/jpg"];
const MAX = 6 * 1024 * 1024;

interface Analysis {
  subject: string | null;
  testName: string | null;
  chapter: string | null;
  studentName: string | null;
  marksObtained: number | null;
  maxMarks: number | null;
  percentage: number | null;
  confidence: number;
}

function analyze(
  subject: string | null,
  testName: string | null,
  chapter: string | null,
  studentName: string | null,
  marks: number | null,
  maxMarks: number | null,
  testDate: string | null
): Analysis {
  const hasMarks =
    marks != null && maxMarks != null && maxMarks > 0 && marks >= 0 && marks <= maxMarks;
  const hasSubject = !!subject && subject.trim().length > 0;
  let confidence = 35;
  let percentage: number | null = null;
  if (hasMarks) {
    percentage = Math.round(((marks as number) / (maxMarks as number)) * 100);
    confidence = hasSubject ? 94 : 78;
  } else if (hasSubject) {
    confidence = 55;
  }
  return {
    subject: hasSubject ? subject : null,
    testName: testName || null,
    chapter: chapter || null,
    studentName: studentName || null,
    marksObtained: hasMarks ? marks : null,
    maxMarks: hasMarks ? maxMarks : null,
    percentage,
    confidence,
    ...(testDate ? {} : {}),
  };
}

export async function GET() {
  const u = await requireUser();
  if (!u) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await db
    .select()
    .from(results)
    .where(eq(results.userId, u.id))
    .orderBy(desc(results.createdAt));
  return NextResponse.json({ results: rows });
}

export async function POST(req: Request) {
  const u = await requireUser();
  if (!u) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const fd = await req.formData();
  const file = fd.get("file");
  if (!(file instanceof File))
    return NextResponse.json({ error: "No file uploaded." }, { status: 400 });
  if (!ALLOWED.includes(file.type))
    return NextResponse.json(
      { error: "Unsupported format. Use JPG, PNG or WEBP." },
      { status: 400 }
    );
  if (file.size > MAX)
    return NextResponse.json({ error: "File too large (max 6MB)." }, { status: 400 });

  const buf = Buffer.from(await file.arrayBuffer());
  const sig = await computeImageSignature(buf);
  const settings = await getAllSettings();
  const dup = await detectDuplicate(
    sig.content,
    sig.phash,
    num(settings.duplicate_threshold, 5),
    num(settings.possible_duplicate_threshold, 10)
  );

  const subject = (fd.get("subject") as string)?.trim() || null;
  const testName = (fd.get("testName") as string)?.trim() || null;
  const chapter = (fd.get("chapter") as string)?.trim() || null;
  const studentName = (fd.get("studentName") as string)?.trim() || null;
  const testDate = (fd.get("testDate") as string)?.trim() || null;
  const marks = fd.get("marks") ? Number(fd.get("marks")) : null;
  const maxMarks = fd.get("maxMarks") ? Number(fd.get("maxMarks")) : null;
  const analysis = analyze(subject, testName, chapter, studentName, marks, maxMarks, testDate);

  if (dup.kind === "exact" || dup.kind === "duplicate") {
    await db.insert(results).values({
      userId: u.id,
      ...analysis,
      status: "duplicate",
      imageHash: sig.content,
      perceptualHash: sig.phash,
      imageDataUrl: sig.display,
      testDate,
    });
    return NextResponse.json({
      status: "duplicate",
      analysis,
      message:
        "DUPLICATE RESULT DETECTED — this image appears to have already been submitted. No XP awarded.",
    });
  }

  const [row] = await db
    .insert(results)
    .values({
      userId: u.id,
      ...analysis,
      status: "pending",
      imageHash: sig.content,
      perceptualHash: sig.phash,
      imageDataUrl: sig.display,
      testDate,
    })
    .returning();

  return NextResponse.json({
    status: "pending",
    analysis,
    result: row,
    possibleDuplicate: dup.kind === "possible" ? { distance: dup.distance } : null,
  });
}

export async function PATCH(req: Request) {
  const u = await requireUser();
  if (!u) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const { id, action } = body;
  if (!id) return NextResponse.json({ error: "Missing id." }, { status: 400 });

  const rows = await db.select().from(results).where(eq(results.id, id)).limit(1);
  const r = rows[0];
  if (!r || r.userId !== u.id)
    return NextResponse.json({ error: "Not found." }, { status: 404 });

  if (action === "cancel") {
    await db.delete(results).where(eq(results.id, id));
    return NextResponse.json({ ok: true });
  }

  const settings = await getAllSettings();
  const analysis = analyze(
    body.subject ?? r.subject,
    body.testName ?? r.testName,
    body.chapter ?? r.chapter,
    body.studentName ?? r.studentName,
    body.marks != null ? Number(body.marks) : r.marksObtained,
    body.maxMarks != null ? Number(body.maxMarks) : r.maxMarks,
    body.testDate ?? r.testDate
  );
  const minConf = num(settings.analyzer_confidence_min, 70);

  if (analysis.confidence >= minConf && r.status !== "verified") {
    await db
      .update(results)
      .set({ ...analysis, status: "verified", testDate: body.testDate ?? r.testDate })
      .where(eq(results.id, id));
    const award =
      num(settings.xp_per_verified_result, 50) +
      num(settings.xp_per_image_verified, 3);
    const res = await applyXp(
      u.id,
      award,
      "Verified test result (+image-analysis bonus)",
      "result"
    );
    return NextResponse.json({
      status: "verified",
      analysis,
      xpAwarded: award,
      leveledUp: res?.leveledUp,
      newLevel: res?.newLevel,
    });
  }

  await db
    .update(results)
    .set({ ...analysis, status: "pending", testDate: body.testDate ?? r.testDate })
    .where(eq(results.id, id));
  return NextResponse.json({
    status: "pending",
    analysis,
    message: "Analyzer uncertain — sent to manual review.",
  });
}
