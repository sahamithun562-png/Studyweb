import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  hashPassword,
  verifyPassword,
  createSession,
  setSessionCookie,
  destroySession,
  checkRateLimit,
  recordFailedLogin,
  clearFailedLogin,
} from "@/lib/auth";
import { profileOf } from "@/lib/public";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function ip(req: Request) {
  const xf = req.headers.get("x-forwarded-for");
  return (xf?.split(",")[0] || "local").trim();
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const action = body.action as string;
  const clientIp = ip(req);

  if (action === "logout") {
    await destroySession();
    return NextResponse.json({ ok: true });
  }

  const username = String(body.username || "").trim();
  const password = String(body.password || "");
  const key = `${clientIp}:${username.toLowerCase()}`;

  if (action === "register") {
    const rl = checkRateLimit(`reg:${clientIp}`);
    if (!rl.ok)
      return NextResponse.json(
        { error: `Too many attempts. Retry in ${rl.retryAfter}s.` },
        { status: 429 }
      );
    if (username.length < 3 || username.length > 24)
      return NextResponse.json(
        { error: "Username must be 3–24 characters." },
        { status: 400 }
      );
    if (password.length < 4)
      return NextResponse.json({ error: "Password too short." }, { status: 400 });
    const existing = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.username, username))
      .limit(1);
    if (existing.length) {
      recordFailedLogin(`reg:${clientIp}`);
      return NextResponse.json({ error: "Username already taken." }, { status: 409 });
    }
    const hash = await hashPassword(password);
    const [u] = await db
      .insert(users)
      .values({
        username,
        passwordHash: hash,
        avatarSeed: username.toLowerCase(),
      })
      .returning();
    const token = await createSession(u.id);
    await setSessionCookie(token);
    clearFailedLogin(`reg:${clientIp}`);
    return NextResponse.json({ user: await profileOf(u) });
  }

  if (action === "login") {
    const rl = checkRateLimit(key);
    if (!rl.ok)
      return NextResponse.json(
        { error: `Too many failed attempts. Locked for ${rl.retryAfter}s.` },
        { status: 429 }
      );
    const rows = await db
      .select()
      .from(users)
      .where(eq(users.username, username))
      .limit(1);
    const u = rows[0];
    const ok = u && (await verifyPassword(password, u.passwordHash));
    if (!ok) {
      recordFailedLogin(key);
      return NextResponse.json({ error: "Invalid credentials." }, { status: 401 });
    }
    if (u.status === "blocked")
      return NextResponse.json(
        { error: "This account has been blocked." },
        { status: 403 }
      );
    const token = await createSession(u.id);
    await setSessionCookie(token);
    clearFailedLogin(key);
    return NextResponse.json({ user: await profileOf(u) });
  }

  return NextResponse.json({ error: "Unknown action." }, { status: 400 });
}
