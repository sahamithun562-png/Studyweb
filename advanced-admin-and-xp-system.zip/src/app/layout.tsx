import type { Metadata } from "next";
import "./globals.css";
import { AppShell } from "@/components/fx";

export const metadata: Metadata = {
  title: "AURORA — Academic Command Center",
  description:
    "A futuristic academic tracker fused with a game-style rank & XP system. Submit results, climb ranks, claim gifts.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&family=Rajdhani:wght@500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="app-body">
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
