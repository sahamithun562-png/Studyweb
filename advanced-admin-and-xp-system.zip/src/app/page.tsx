"use client";

import Link from "next/link";
import { RankOrb } from "@/components/ui";

const RANKS = [
  { name: "CLASSIC", color: "#cbd5e1", glow: "#e2e8f0", badge: "◇", effect: "fx-glow", desc: "Silver / white · simple glow" },
  { name: "LEGENDARY", color: "#ffd24a", glow: "#ffae00", badge: "★", effect: "fx-border-flow", desc: "Gold · animated border" },
  { name: "MYTHICAL", color: "#b06bff", glow: "#d8b4fe", badge: "✦", effect: "fx-aura", desc: "Purple · energy aura" },
  { name: "GOD", color: "#fff3c4", glow: "#ffd24a", badge: "✸", effect: "fx-aura fx-glow", desc: "White / gold · celestial glow" },
  { name: "GALAXY", color: "#6d8bff", glow: "#b06bff", badge: "✺", effect: "fx-stars fx-aura", desc: "Cosmic · moving stars" },
  { name: "INF", color: "#22d3ee", glow: "#ff4df0", badge: "∞", effect: "fx-border-flow fx-aura fx-multicolor", desc: "Multicolor · premium border" },
];

export default function Home() {
  return (
    <main className="page-in" style={{ minHeight: "100vh", padding: "1.4rem clamp(1rem,4vw,4rem)" }}>
      <nav style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div className="rank-orb fx-glow" style={{ width: 44, height: 44, fontSize: "1.1rem", "--rk-color": "#22d3ee", "--rk-glow": "#4f7bff" } as React.CSSProperties}>A</div>
          <span style={{ fontFamily: "Orbitron", fontWeight: 800, letterSpacing: ".2em", fontSize: "1.2rem" }}>AURORA</span>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <Link className="btn btn-ghost" href="/scoreboard">Scoreboard</Link>
          <Link className="btn btn-ghost" href="/portfolio">Portfolio</Link>
          <Link className="btn btn-primary" href="/auth">Enter</Link>
        </div>
      </nav>

      <section style={{ maxWidth: 1100, margin: "clamp(2rem,8vh,6rem) auto", textAlign: "center" }}>
        <div className="float" style={{ display: "inline-block", padding: "0.4rem 1rem", borderRadius: 999, border: "1px solid var(--border)", fontFamily: "Orbitron", letterSpacing: ".2em", fontSize: ".72rem", color: "var(--neon-2)", marginBottom: 24 }}>
          ACADEMIC TRACKER × GAME RANK SYSTEM
        </div>
        <h1 style={{ fontSize: "clamp(2.4rem,7vw,5rem)", lineHeight: 1.02, margin: "0 auto", maxWidth: 900, fontWeight: 800 }}>
          <span style={{ background: "linear-gradient(90deg,#4f7bff,#22d3ee,#a855f7,#ffd24a)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
            COMMAND YOUR
          </span>
          <br />
          ACADEMIC DESTINY
        </h1>
        <p style={{ color: "var(--muted)", maxWidth: 640, margin: "1.4rem auto 2rem", fontSize: "1.05rem" }}>
          Submit school & tuition results, let the analyzer extract your marks, dodge duplicate submissions,
          earn XP, level up and climb from <b style={{ color: "#cbd5e1" }}>CLASSIC</b> to{" "}
          <b style={{ color: "#22d3ee" }}>INF</b>.
        </p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <Link className="btn btn-primary" href="/auth" style={{ padding: "0.9rem 1.6rem", fontSize: ".9rem" }}>▶ Launch Dashboard</Link>
          <Link className="btn" href="/scoreboard" style={{ padding: "0.9rem 1.6rem", fontSize: ".9rem" }}>View Scoreboard</Link>
          <Link className="btn btn-gold" href="/portfolio" style={{ padding: "0.9rem 1.6rem", fontSize: ".9rem" }}>Portfolio</Link>
        </div>
      </section>

      <section style={{ maxWidth: 1200, margin: "0 auto" }}>
        <h2 style={{ textAlign: "center", fontFamily: "Orbitron", letterSpacing: ".14em", fontSize: ".9rem", color: "var(--muted)", marginBottom: 28 }}>
          ASCEND THE RANKS
        </h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 18 }}>
          {RANKS.map((r) => (
            <div key={r.name} className="glass card-hover hud" style={{ padding: "1.4rem 1rem", textAlign: "center" }}>
              <RankOrb role={r} size={84} label />
              <p style={{ color: "var(--muted)", fontSize: ".72rem", marginTop: 12, minHeight: 32 }}>{r.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1100, margin: "4rem auto 0", display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 18 }}>
        {[
          { t: "Smart Analyzer", d: "Upload a result image — the analyzer extracts subject, marks & percentage, then verifies.", i: "🧠" },
          { t: "Duplicate Shield", d: "Perceptual hashing blocks renamed, resized or recompressed resubmissions.", i: "🛡️" },
          { t: "XP & Levels", d: "Verified activity grants XP. Level up with particles, glow and sound.", i: "⚡" },
          { t: "Gift Box", d: "Admins gift exclusive roles that open with a cinematic light burst.", i: "🎁" },
        ].map((f) => (
          <div key={f.t} className="glass hud" style={{ padding: "1.4rem" }}>
            <div style={{ fontSize: "1.8rem" }}>{f.i}</div>
            <h3 style={{ fontFamily: "Orbitron", fontSize: ".9rem", letterSpacing: ".08em", marginTop: 10 }}>{f.t}</h3>
            <p style={{ color: "var(--muted)", fontSize: ".85rem", marginTop: 6 }}>{f.d}</p>
          </div>
        ))}
      </section>

      <footer style={{ textAlign: "center", color: "var(--muted)", padding: "4rem 0 2rem", fontSize: ".8rem" }}>
        <div style={{ display: "flex", gap: 16, justifyContent: "center", marginBottom: 12 }}>
          <Link className="btn btn-ghost" href="/scoreboard" style={{ fontSize: ".7rem" }}>Scoreboard</Link>
          <Link className="btn btn-ghost" href="/portfolio" style={{ fontSize: ".7rem" }}>Portfolio</Link>
          <Link className="btn btn-ghost" href="/admin/login" style={{ fontSize: ".7rem" }}>Admin Access</Link>
        </div>
        AURORA Command Center · Original futuristic design · All rights reserved.
      </footer>
    </main>
  );
}
